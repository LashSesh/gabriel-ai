GABRIEL AI — SYSTEM ARCHITECTURE AND IMPLEMENTATION BLUEPRINT
Version 1.1 — 2 October 2026

PURPOSE
A complete English engineering blueprint grounded in the rescued repository:
https://github.com/LashSesh/gabriel-ai
Baseline commit: ed3da014e41999b4201b1654c8b2667ed907636b
Additional donor: https://github.com/LashSesh/kosmocrates
Donor commit: a320ad101bbf0fdcde85d4617366ddee435d40b8
The agent application described here is PROPOSED. This package contains the
blueprint, public contract specifications, evidence and a limited executable
kernel reference. It does not contain a built agent.

READ FIRST
main.tex / the separately delivered Gabriel_AI_Blueprint.pdf
The PDF contains the whole architecture, contracts, acceptance programme and
coding-agent mission. Machine-readable assets support implementation of the
same design. No ZIP or executable payload is embedded in the PDF.

BUILD THE PDF
Required: a standard TeX distribution with pdflatex, BibTeX, Latin Modern,
TikZ/PGF, hyperref, xurl, needspace and the usual article/table packages.
All document content and diagrams are included locally. No private repository,
network access or custom external font is needed for compilation.

From this directory:
  python3 tools/build_pdf.py --output ./build

Or run pdflatex main.tex, bibtex main, and pdflatex main.tex twice.
The diagrams are native TikZ in the supplied LaTeX sources. parskip is used; paragraph
indentation is explicitly zero. references.bib contains the verified official
technical sources; repository provenance is given in the text and manifests.

SPECIFICATION VALIDATION
Install the exact validator dependency versions from contracts/validator-requirements.txt
in an isolated Python environment, then run:
  python3 tools/validate_spec.py
See contracts/README.txt for coverage, examples and invariants.
This validates specification assets. It DOES NOT run future agent acceptance
cases or implement the state owner, policy broker, sandbox or planner.

REPRODUCING THE EXTRA LEGACY PROBE
Check out the private source repository at the baseline commit with access
appropriate to your GitHub account. Install its declared runtime dependencies.
Then, from this package:
  python3 evidence/runtime_contract_probe.py --source /path/to/gabriel-ai \
    --output /path/to/new_probe_report.json

The probe was rerun successfully with this portable entry point. Its original
and portable reports are retained. The inherited check_runtime.py remains in
the source repository; run it from an isolated checkout because it writes its
own evidence outputs. Large benchmark histories and LFS payloads are not
included in this blueprint package. They are not LaTeX dependencies.

EVIDENCE STATUS
- Full pinned tree inventory and 282 retrieved text-file hash identities.
- Focused architecture/source inspection, not proof of every saved experiment.
- Executed synthetic legacy checks: 3449 assertions in 98 named categories.
- Executed owner/replay probe and synthetic CLI demo/audit/inspect.
- Executed specification validation and PDF build/layout inspection.
- 798 unique donor unit tests passed after resolving an environment-only
  loopback restriction; initial failure and rerun logs are retained.
- Four external Rust counterexamples reproduced incomplete identity, false
  convergence interpretation and arithmetic overflow fallback.
- 23 Python kernel-reference tests passed on synthetic fixtures.
- No full-agent, Rust-performance or predictive benchmark executed.
- AT01–AT25 in the contracts package are future product acceptance cases.

NEW EXECUTABLE REFERENCE
Run with Python standard library only:
  python3 reproduction/kernel_reference/run_checks.py
The runner writes checks.json, checks.log and examples.json next to itself.
The supplied outputs record the actual design-reference execution, not agent
acceptance. It assumes trusted evidence and gate inputs; no broker, artifact
resolver, production verifier authority or sandbox is implemented here.

DONOR COUNTEREXAMPLES
See reproduction/kosmocrates_probe/README.txt for the portable pinned-source
runner, dependency prerequisites and recorded outputs. The source checkout
is required only to repeat donor-library checks, not to build the PDF.

VERSION 1.1 CHANGES
The single PDF now incorporates the Kosmocrates audit, component migration
register, neutral goal/evidence kernel, domain-pack ports and extended
acceptance programme. Software observation and patching stay in a domain
adapter. Existing Gabriel state ownership and authority boundaries remain.
Pure reference code and reproduction material support the same document.
Source audit notes distinguish inspection from actual execution.

HANDOFF
Implement WP01–WP08 first, then the applicable evaluation/release gates.
Preserve the legacy runtime behind its own compatibility boundary. The
Implementation-agent mission in the PDF is intended as the initial coding
agent instruction. Work in a branch/worktree and deliver reviewable code and
actual evidence. Remote publishing/merging requires the authority given for
that implementation task; this package makes no GitHub changes.

INTEGRITY
SHA256SUMS.txt covers supplied files except itself. It detects accidental byte
changes relative to this manifest; it is not an independent signature.
