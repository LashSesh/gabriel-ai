"""Build the self-contained LaTeX document using a standard TeX installation."""
import argparse
import shutil
import subprocess
from pathlib import Path
p = argparse.ArgumentParser()
p.add_argument('--output', type=Path, default=Path('build'))
a = p.parse_args()
root = Path(__file__).resolve().parents[1]
out = a.output.resolve()
out.mkdir(parents=True, exist_ok=True)
for program in ('pdflatex', 'bibtex'):
    if shutil.which(program) is None:
        raise SystemExit(f'Required standard TeX executable not found: {program}')
# Copy the small complete document into the requested build directory. No network.
for name in ('main.tex', 'references.bib', 'contract_appendix.tex', 'kosmocrates_baseline.tex', 'domain_kernel.tex', 'kosmocrates_validation.tex'):
    if (root / name).exists():
        shutil.copy2(root / name, out / name)
for name in ('figures',):
    if (root / name).exists():
        shutil.copytree(root / name, out / name, dirs_exist_ok=True)
commands = [['pdflatex', '-interaction=nonstopmode', '-halt-on-error', 'main.tex'],
            ['bibtex', 'main'],
            ['pdflatex', '-interaction=nonstopmode', '-halt-on-error', 'main.tex'],
            ['pdflatex', '-interaction=nonstopmode', '-halt-on-error', 'main.tex']]
for i, command in enumerate(commands):
    result = subprocess.run(command, cwd=out, capture_output=True, text=True)
    (out / f'build-{i+1}.log').write_text(result.stdout + result.stderr)
    if result.returncode:
        raise SystemExit(f'Build failed: {command[0]}; see {out / f"build-{i+1}.log"}')
log = (out / 'main.log').read_text()
for error in ('undefined references', 'undefined citations', 'Overfull \\hbox', 'Overfull \\vbox'):
    if error in log:
        raise SystemExit(f'Layout/reference check needs review: {error}; see {out / "main.log"}')
shutil.copy2(out / 'main.pdf', out / 'Gabriel_AI_Blueprint.pdf')
print(out / 'Gabriel_AI_Blueprint.pdf')
