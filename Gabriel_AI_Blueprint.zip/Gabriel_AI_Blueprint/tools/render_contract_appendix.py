"""Render the PDF's field catalogue and acceptance programme from delivered JSON."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
C=ROOT/'contracts'
def esc(s):
    chars={'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}
    return ''.join(chars.get(c,c) for c in str(s))
def path(s): return r'\path{'+str(s)+'}'
def desc(x,depth=0):
    if '$ref' in x: return path(x['$ref'].split('#/$defs/')[-1].replace('.schema.json',''))
    if 'const' in x: return 'constant '+path(x['const'])
    if 'enum' in x: return ', '.join(path(v) for v in x['enum'])
    for alt in ('anyOf','oneOf'):
        if alt in x: return ' or '.join(desc(z,depth+1) for z in x[alt])
    t=x.get('type','specified value')
    if t=='object':
        props=x.get('properties',{})
        return 'closed object: '+', '.join(path(k) for k in props) if props else 'object'
    if t=='array':
        n=f"{x.get('minItems',0)}--{x.get('maxItems','bounded')} items"
        return 'array ('+n+'): '+desc(x.get('items',{}),depth+1)
    if t=='integer':
        m=x.get('maximum'); ma=r'$2^{53}-1$' if m==9007199254740991 else esc(m) if m is not None else 'profile bound'
        return f"integer {esc(x.get('minimum',0))} to {ma}"
    if t=='string' and 'pattern' in x:
        return 'ASCII string; '+('64 lowercase hex digits' if x['pattern']=='^[0-9a-f]{64}$' else f"validated pattern, max {x.get('maxLength','profile')} characters")
    return esc(t)
def table(rows):
    return '\n'.join([r'\Needspace{5\baselineskip}',r'\begin{longtable}{@{}L{.32\textwidth}L{.60\textwidth}@{}}',r'\toprule Field & Representation / constraint\\\midrule\endhead']+[a+' & '+b+r'\\' for a,b in rows]+[r'\bottomrule\end{longtable}'])
out=[r'\section{Public contract field catalogue}',r'\label{sec:catalogue}',
'This catalogue makes the principal wire fields available in the monolithic PDF. All fields listed for the public objects are required unless stated otherwise; nullable fields must still be present. Objects reject unknown keys. Detailed lexical patterns and structural conditionals are supplied as local Draft 2020-12 schemas. The common exact-JSON parser additionally rejects duplicate keys, floating tokens and Boolean values in integer fields. Cross-record behavior remains governed by the main text.',
'An identifier is an ASCII letter or digit followed by at most 127 letters, digits, dots, underscores, colons or hyphens. A digest is 64 lowercase hexadecimal digits. A safe unsigned integer is between zero and $2^{53}-1$. Schema identifiers under \\code{https://gabriel.invalid} are local namespace identifiers, not network resources. Artifact references preserve exact original bytes.',
f'The sample records are synthetic representations, not an executed task history. Their {len(list((C / "examples/objects").glob("*.blob")))} object blobs are included and byte-checked; dummy policy/model/verifier identities are not authenticated deployments. DomainPack implementation descriptors are non-executable fixtures, not registered handlers. The zero sample currency limit authorizes no paid model call.']
common=json.loads((C/'schemas/common.schema.json').read_text())['$defs']
for k in ('artifact_ref','budget','usage','check_ref'):
    x=common[k];out.append(r'\subsection{Common type: '+esc(k)+'}')
    out.append(table([(path(n),desc(v)) for n,v in x['properties'].items()]))
    if k=='budget':out.append('The elapsed-time allowance is a run deadline, excluded from the additive resource ledger. Artifact bytes bound an ordinary individual result; scratch bytes bound worker disk allocation. Currency exposure and hard/advisory limits follow Section~\\ref{sec:policy}.')
for name in ['task','run','command','event','grant','plan','model-request','intent','dispatch-marker','result','assessment','observation','claim','outcome-label','domain-pack']:
    x=json.loads((C/'schemas'/f'{name}.schema.json').read_text())
    out.append(r'\subsection{'+esc(x.get('title',name))+'}')
    rows=[]
    for k,v in x.get('properties',{}).items():
        label=path(k)+(' (optional)' if k not in x.get('required',[]) else '')
        rows.append((label,desc(v)))
    out.append(table(rows))
    if name=='domain-pack':
        out.append('The six required ports are compile, observe, evaluate, propose, execute and read\\_back. Each uses the nested port type below. Manifest registration checks complete immutable bytes, referenced profiles and implementation fingerprints; it grants no execution rights. Required fixture classes are valid, invalid and out\\_of\\_scope. The fixture implementation descriptor is explicitly NOT IMPLEMENTED. Logical pack identity is distinct from the digest of the complete manifest.')
    # Nested plan, result and domain types need their contents in the PDF.
    for k,v in x.get('$defs',{}).items():
        if v.get('properties'):
            out.append('Nested type '+path(k)+':')
            out.append(table([(path(n),desc(z)) for n,z in v['properties'].items()]))
out.extend([r'\section{Product acceptance programme}',r'\label{sec:acceptance}',
'These are the specified future product acceptance cases. They remain NOT EXECUTED for the proposed agent. The fresh legacy and specification checks actually performed are reported separately in Appendix~\\ref{sec:checks}. Each case retains the stated inputs, outputs and failure evidence.'])
for c in json.loads((C/'acceptance-cases.json').read_text())['cases']:
    out.append(r'\Needspace{7\baselineskip}')
    out.append(r'\subsection{'+esc(c['id']+': '+c['title'])+'}')
    out.append(r'\textbf{Procedure.} '+esc(c['procedure']))
    out.append(r'\textbf{Required outcome.} '+esc(c['expected']))
    out.append(r'\textbf{Evidence.} '+esc('; '.join(c['required_evidence']))+'. '+r'\textbf{Trace:} '+esc(', '.join(c['requirement_ids']))+'.')
out.extend([r'\subsection{Work-package dependency map}',
'G1 follows WP01--WP08, then the G1 evaluation and release portions of WP11--WP12. Optional WP09 and WP10 gate the corresponding G2 extensions; adaptive-policy promotion also requires its G3 comparison. A package dependency authorizes development sequencing, not a claim of success.'])
rows=[]
for w in json.loads((C/'work-packages.json').read_text())['packages']:
    rows.append((esc(w['id']),esc('Depends on: '+(', '.join(w['depends_on']) or 'none')+'; acceptance: '+', '.join(w['acceptance_ids']))))
out.append(table(rows))
out.append(r'\subsection{Release-scoped acceptance}')
for level,scope in json.loads((C/'work-packages.json').read_text())['release_scopes'].items():
    out.append(r'\textbf{'+esc(level)+'}: '+esc(', '.join(scope['required_acceptance_ids']))+'. '+esc(scope['extension_rule']))
(ROOT/'contract_appendix.tex').write_text('\n\n'.join(out)+'\n')
print('Generated contract_appendix.tex')
