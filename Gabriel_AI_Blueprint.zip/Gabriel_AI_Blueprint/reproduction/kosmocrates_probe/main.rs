//! Non-I/O adversarial probes against the unchanged pinned Kosmocrates source.
//! Assertions deliberately reproduce limitations, not corrected behavior.
use kosmo_core::{assess_wish, Digest, ObservedTopology, Q16, Wish, WishConvergenceTrace,
                 WishFacet, WishPredicate};
use kosmo_synthesizer::{FileChange, Patch};

fn convergence_probe(weight: Q16) -> (i64, usize, bool) {
    let evidence = Digest::of_bytes(b"synthetic-probe-evidence");
    let present = WishFacet::symbol("present");
    let missing = WishFacet::symbol("missing");
    let wish = Wish::new("synthetic goal", [
        WishPredicate::weighted(present.clone(), Q16::ONE),
        WishPredicate::weighted(missing, weight),
    ], Digest::of_bytes(b"synthetic-policy"), evidence);
    let observed = ObservedTopology::from_facets([present]);
    let assessment = assess_wish(&wish, &observed, evidence);
    assert!(!assessment.is_realized());
    assert_eq!(assessment.unmet_facets.len(), 1);
    assert!(assessment.distance.is_zero());
    let trace = WishConvergenceTrace::from_assessments(&[assessment.clone()], evidence);
    assert!(trace.is_converged());
    (assessment.distance.raw(), assessment.unmet_facets.len(), trace.is_converged())
}

fn main() {
    let request = Digest::of_bytes(b"synthetic-request");
    let create = Patch::new(request, vec![FileChange::create("x", "")], "probe");
    let delete = Patch::new(request, vec![FileChange::delete("x")], "probe");
    assert_ne!(create.file_changes[0].kind, delete.file_changes[0].kind);
    assert_eq!(create.patch_id, delete.patch_id);
    let zero = convergence_probe(Q16::ZERO);
    let rounded = convergence_probe(Q16::from_raw(1));
    let gm = Q16::geomean(&[Q16::HALF; 9]);
    assert_eq!(gm, Q16::ONE);
    assert_ne!(gm, Q16::HALF);
    println!("{{\"source_commit\":\"a320ad101bbf0fdcde85d4617366ddee435d40b8\",\"counterexamples_reproduced\":4,\"patch_kind_collision\":{{\"same_id\":true,\"distinct_operations\":[\"Create\",\"Delete\"]}},\"unmet_zero_weight\":{{\"distance_raw\":{},\"unmet_count\":{},\"trace_converged\":{}}},\"unmet_positive_weight_rounding\":{{\"missing_weight_raw\":1,\"distance_raw\":{},\"unmet_count\":{},\"trace_converged\":{}}},\"geomean_overflow\":{{\"inputs\":9,\"input_raw\":32768,\"expected_raw\":32768,\"actual_raw\":{}}}}}", zero.0, zero.1, zero.2, rounded.0, rounded.1, rounded.2, gm.raw());
}
