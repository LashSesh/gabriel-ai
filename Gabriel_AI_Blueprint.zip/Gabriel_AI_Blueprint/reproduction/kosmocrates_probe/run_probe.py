#!/usr/bin/env python3
"""Run four non-I/O counterexamples against an unchanged pinned source checkout.

Python standard library only. Cargo dependencies must already be cached.
This runner never fetches, modifies, or checks out source for the caller.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import signal
import subprocess
import sys
import tempfile
import time

PIN = "a320ad101bbf0fdcde85d4617366ddee435d40b8"
HERE = Path(__file__).resolve().parent


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_read(args: list[str], cwd: Path) -> str:
    return subprocess.check_output(args, cwd=cwd, text=True, stderr=subprocess.PIPE,
                                   timeout=30).strip()


def verify_source(source: Path, manifest: dict) -> dict:
    head = run_read(["git", "rev-parse", "HEAD"], source)
    if head != PIN or manifest["commit"] != PIN:
        raise ValueError(f"Expected commit {PIN}, found {head}")
    dirty = run_read(["git", "status", "--porcelain", "--untracked-files=all"], source)
    if dirty:
        raise ValueError("Source checkout is dirty or contains untracked files; use a clean pinned checkout.")
    mismatches = []
    for entry in manifest["files"]:
        path = (source / entry["path"]).resolve()
        if not path.is_relative_to(source):
            raise ValueError("Source manifest contains a path outside its checkout")
        if not path.is_file() or sha256(path) != entry["sha256"]:
            mismatches.append(entry["path"])
    if mismatches:
        raise ValueError("Source byte mismatch: " + ", ".join(mismatches[:10]))
    return {"commit": head, "tracked_files_verified": len(manifest["files"]),
            "dirty": False, "sha256_mismatches": []}


def cargo_manifest(source: Path) -> str:
    # JSON string quoting is valid for these TOML basic string values; paths
    # are converted to forward slashes, preserving spaces and Unicode safely.
    quote = lambda p: json.dumps(str(p.as_posix()), ensure_ascii=False)
    return ("[package]\nname = \"kosmocrates-counterexample-probe\"\n"
            "version = \"0.1.0\"\nedition = \"2021\"\npublish = false\n\n"
            "[workspace]\n\n[dependencies]\n"
            "kosmo-core = { path = " + quote(source / "crates/kosmo-core") + " }\n"
            "kosmo-synthesizer = { path = " + quote(source / "crates/kosmo-synthesizer") + " }\n")


def check_result(result: dict) -> None:
    if result.get("source_commit") != PIN or result.get("counterexamples_reproduced") != 4:
        raise ValueError("Unexpected probe identity/count")
    if result["patch_kind_collision"]["same_id"] is not True:
        raise ValueError("Patch collision was not reproduced")
    for key in ["unmet_zero_weight", "unmet_positive_weight_rounding"]:
        case = result[key]
        if (case["distance_raw"], case["unmet_count"], case["trace_converged"]) != (0, 1, True):
            raise ValueError("Wish counterexample was not reproduced: " + key)
    gm = result["geomean_overflow"]
    if (gm["inputs"], gm["input_raw"], gm["expected_raw"], gm["actual_raw"]) != (9, 32768, 32768, 65536):
        raise ValueError("Geometric-mean counterexample was not reproduced")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, type=Path, help="Clean checkout at the pinned Kosmocrates commit")
    parser.add_argument("--output", required=True, type=Path, help="Output directory outside the source checkout")
    parser.add_argument("--cargo", default="cargo", help="Cargo executable (not a shell command)")
    parser.add_argument("--timeout", type=int, default=180, help="Build/run wall-time ceiling in seconds")
    args = parser.parse_args()
    source, output = args.source.resolve(), args.output.resolve()
    if not source.is_dir() or output.is_relative_to(source) or args.timeout <= 0:
        parser.error("Use an existing source checkout, positive timeout, and output outside that checkout.")
    output.mkdir(parents=True, exist_ok=True)
    if any((output / n).exists() for n in ["run_summary.json", "probe_stdout.json", "cargo_stderr.log"]):
        parser.error("Output already contains probe results; choose a new output directory.")
    summary = {"source_commit": PIN, "status": "FAILED", "scope": "Four non-I/O counterexamples; no unit suite or benchmark", 
               "python": sys.version.split()[0], "platform": platform.platform(), "offline": True}
    exit_code = 1
    try:
        manifest = json.loads((HERE / "source_manifest.json").read_text(encoding="utf-8"))
        summary["source_before"] = verify_source(source, manifest)
        target = Path(os.environ.get("CARGO_TARGET_DIR", str(output / "target"))).resolve()
        if target.is_relative_to(source):
            raise ValueError("CARGO_TARGET_DIR must be outside the source checkout")
        env = os.environ.copy()
        env["CARGO_TARGET_DIR"] = str(target)
        env["CARGO_NET_OFFLINE"] = "true"
        env["CARGO_INCREMENTAL"] = "0"
        summary["artifact_sha256"] = {n: sha256(HERE / n) for n in ["main.rs", "Cargo.lock", "source_manifest.json"]}
        summary["cargo"] = run_read([args.cargo, "--version"], output)
        summary["rustc"] = run_read(["rustc", "--version"], output)
        summary["toolchain_environment"] = {k: env.get(k) for k in ["RUSTUP_TOOLCHAIN", "CARGO_HOME", "RUSTUP_HOME"]}
        with tempfile.TemporaryDirectory(prefix="kosmo-probe-", dir=output) as temp_name:
            temp = Path(temp_name)
            (temp / "src").mkdir()
            shutil.copyfile(HERE / "main.rs", temp / "src/main.rs")
            shutil.copyfile(HERE / "Cargo.lock", temp / "Cargo.lock")
            manifest_text = cargo_manifest(source)
            (temp / "Cargo.toml").write_text(manifest_text, encoding="utf-8")
            (output / "generated_Cargo.toml.txt").write_text(manifest_text, encoding="utf-8")
            command = [args.cargo, "run", "--manifest-path", str(temp / "Cargo.toml"), "--locked", "--offline"]
            summary["command"] = command
            summary["cwd"] = str(temp)
            summary["target_dir"] = str(target)
            started = time.monotonic()
            process = subprocess.Popen(command, cwd=temp, env=env, stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE, text=True, start_new_session=(os.name == "posix"))
            try:
                stdout, stderr = process.communicate(timeout=args.timeout)
            except subprocess.TimeoutExpired:
                if os.name == "posix":
                    os.killpg(process.pid, signal.SIGKILL)
                else:
                    process.kill()
                stdout, stderr = process.communicate()
                summary["timed_out"] = True
            summary["elapsed_seconds"] = round(time.monotonic() - started, 3)
            summary["cargo_exit_code"] = process.returncode
            (output / "probe_stdout.json").write_text(stdout, encoding="utf-8")
            (output / "cargo_stderr.log").write_text(stderr, encoding="utf-8")
            summary["source_after"] = verify_source(source, manifest)
            if process.returncode:
                raise RuntimeError("Cargo/probe failed; inspect cargo_stderr.log. No network retry was attempted.")
            if sha256(temp / "Cargo.lock") != sha256(HERE / "Cargo.lock"):
                raise RuntimeError("Probe lockfile changed unexpectedly")
            result = json.loads(stdout)
            check_result(result)
            summary["result"] = result
            summary["status"] = "COUNTEREXAMPLES_REPRODUCED"
            exit_code = 0
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        summary["error"] = str(error)
    (output / "run_summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": summary["status"], "summary": str(output / "run_summary.json")}, indent=2))
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
