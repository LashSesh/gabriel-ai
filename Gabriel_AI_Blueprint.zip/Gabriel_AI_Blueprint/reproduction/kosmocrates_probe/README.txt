Portable Kosmocrates counterexample probe
========================================

Purpose
Reproduce four inherited behaviors against the unchanged Kosmocrates source at:
a320ad101bbf0fdcde85d4617366ddee435d40b8

This is an executable diagnostic, not a fix and not a passing-correctness claim.
Its successful result means all four defects/inconsistencies were reproduced:
  1. Create(empty) and Delete have the same patch ID.
  2. An unmet zero-weight predicate coexists with scalar Converged.
  3. A positive raw-Q16 weight of 1 yields the same result through quantization.
  4. geomean([HALF; 9]) returns ONE because of the overflow branch.
The categorical Wish assessment remains non-Realized in cases 2 and 3.

Requirements
- Python 3.9 or newer, standard library only.
- Git and a clean local clone of https://github.com/LashSesh/kosmocrates at the
  exact commit above, accessible using the caller's normal repository access.
- Rust/Cargo available on PATH. The executed reference used Rust 1.99.0
  (b940084d7 2026-09-28). MSRV 1.82 was not tested. The source's "stable"
  toolchain declaration is moving, not an exact compiler pin.
- The Cargo dependencies recorded by the supplied Cargo.lock already cached.
  If a fresh machine needs them, deliberately prepare the trusted source cache
  using `cargo fetch --locked` from the pinned source checkout first. That
  command requires network access. The probe runner itself is always offline.
- Source checkout uses its original committed file bytes: source_manifest.json
  verifies SHA-256 for all 1115 tracked files, including Cargo.lock. Git reports
  a clean checkout before and after execution. On Windows, disable Git automatic
  newline conversion for this clone so byte identity can be checked.

Run
  python3 run_probe.py --source /path/to/kosmocrates --output /path/to/new-results

Use a new output directory outside the source checkout. Paths may contain spaces
when correctly quoted for the caller's shell. For a custom toolchain installation,
put rustc/cargo on PATH and set RUSTUP_HOME/CARGO_HOME/RUSTUP_TOOLCHAIN as normal.
Optionally use --cargo /path/to/cargo and --timeout 300. The chosen rustc must
still be on PATH. A shared CARGO_TARGET_DIR is honored only outside the source;
otherwise compiled artifacts go to the output directory's target subdirectory.

What the runner does
It verifies commit identity, clean Git state and all manifest source hashes;
generates a temporary Cargo.toml with safely quoted local path dependencies;
copies main.rs and the supplied lockfile; runs `cargo run --locked --offline`;
checks the emitted JSON and source integrity again; and saves stdout, stderr,
the generated manifest text, and run_summary.json. It does not fetch the source,
edit the source, update the source lockfile, run a live model, or execute generated
application code. The probe Rust program uses only pure in-process APIs.

Scope of recorded validation
The accompanying project/evidence/kosmocrates directory contains the separate
798-test selected library-suite evidence and original counterexample run. Running
this portable probe does not rerun those 798 tests, benchmark performance, or
establish OS isolation. Cargo compilation executes normal dependency build steps;
the runner is not a hostile-code sandbox. Missing cached dependencies fail with
a logged error rather than an automatic network retry.

The source and diagnostic intentionally remain separate: no source repository
is bundled here. Retain the source MIT license notice if copying its code into
another distribution.
