Gabriel goal and candidate contract -- executable reference 0.1
==============================================================

Run (Python 3.10+, standard library only):
    cd kernel_reference
    python3 run_checks.py

Alternative direct test invocation:
    python3 -m unittest -v test_kernel

The runner writes checks.json, checks.log and examples.json beside the sources.
checks.json records actual test totals, environment and source SHA-256 values.
All examples are fabricated, including records labeled execution="observed".
They exercise the contract with three domain labels; they demonstrate neither
working domain adapters nor factual observation, model intelligence or efficacy.

Scope
-----
This is newly authored pure Python specification code, not copied Kosmocrates
code, not a complete Gabriel implementation and not an execution engine. It
does not run models, execute actions, access a database or enforce OS isolation.
No files outside this directory are changed by the runner.

Artifact stores immutable bytes. Canonical JSON envelopes accept ASCII strings,
null, booleans, safe integers, lists and objects; no floats; duplicate JSON keys
are rejected on input. Arbitrary UTF-8 belongs in byte artifacts. Hashes establish
byte identity, not authorship, truth, completeness or authorization. BlobRef
validation checks reference shape; a future artifact store must separately fetch,
hash-verify and retain the referenced bytes. This codec is deliberately named as
a local restricted codec, not as general JSON Canonicalization Scheme compliance.
References use the baseline ArtifactRef fields sha256, bytes, media_type. Raw
artifacts default to application/octet-stream; records use application/json.
Identifiers use the existing pattern [A-Za-z0-9][A-Za-z0-9._:-]{0,127}.

goal() creates a nonempty GoalSpec with immutable domain/profile/parameter
identities and named obligations mapped to their expected oracle identities.
Every listed obligation is mandatory. No priority or distance enters completion.
Quantitative tolerances belong in the parameter artifact interpreted by an oracle.
Production callers need an artifact resolver for parameters, inputs, targets,
payloads and evidence results: this pure kernel does not check referenced bytes.

snapshot() records domain/profile/input identities and the observed frontier.
"observed" and "proposed" snapshots have different identities. A candidate may
reference proposed state, but cannot write it into current observed state here.
Only externally verified readback may supply a new observed snapshot.

assess_goal() accepts a SELECTED CURRENT evidence set, not full history. Historical
revision resolution is outside this API. A repeated obligation, even with the
same evidence bytes, is invalid to avoid accidental double counting/ambiguity.
An unknown obligation or mismatched goal/snapshot/profile/oracle is invalid.
Missing checks yield not_run; synthetic and dry_run checks cannot satisfy an
observed obligation. Out-of-scope and invalid checks cannot satisfy the goal.
Successful assessment requires every obligation to be passed, supported,
observed, and bound to the same goal and current observed snapshot. An invalid
selected evidence set yields inconclusive/invalid. Otherwise aggregate outcome
priority is failed > inconclusive > not_run > passed; aggregate scope priority
is invalid > out_of_scope > supported. Scope and outcome remain separate axes.
Every returned assessment hashes the sorted evidence_ids of ALL inspected check
artifacts, preserving duplicate IDs and rejected foreign/stale inputs. The same
input multiset yields the same identity independent of its traversal order;
different passed result references remain different assessments even when all
categorical verdicts agree. Malformed records that raise do not produce an
assessment artifact and are not represented as an assessed input set.
Malformed records raise ValueError (or input decoding/type errors) rather than
returning success; callers must treat every exception as no assessment result.

candidate() hashes goal, current snapshot, action kind, target reference, payload
reference and proposed state. Ordered compound edits must be an immutable payload
whose own format binds each operation kind and full content; adapters must not
discard semantics before serialization. A candidate describes a proposed effect.
select_candidate() only ranks candidates whose independent gate receipts permit
them under the exact current goal/snapshot/policy. A missing, reject, inconclusive
or stale gate cannot be repaired by a high rank. Ranking uses signed safe integers
and ascending content IDs for ties. Ranking never changes goal satisfaction.
Selection returns a proposal, not authority to bypass later dispatch validation.

Trust boundary
--------------
The caller is assumed to obtain CheckEvidence from a registered trusted verifier
and gate receipts from its policy authority. The API cannot authenticate sources:
any caller can fabricate a correctly hashed passed record. Source authentication,
revocation, oracle isolation, grant freshness, effect dispatch, outbox/reconciliation,
temporal evidence selection and prevention of forged observed snapshots are later
runtime responsibilities. The current prototype tests separation of these fields,
not enforcement of those missing operational mechanisms.

Motivation in the inspected Kosmocrates source
--------------------------------------------
crates/kosmo-core/src/wish.rs, assess_wish, approximately lines 520--580:
  Categorical closure is correctly derived from met_count. Weighted Q16 distance
  is separate and can be zero despite an unmet zero-weight predicate, or after
  quantization. Its zero value must not substitute for categorical completion.
  This reference generalizes positive required facets to oracle-bound obligations.

crates/kosmo-synthesizer/src/lib.rs, Patch::new, approximately lines 214--242:
  The changes hash concatenates path/content but does not bind FileChangeKind.
  This reference hashes action kind and all represented payload/target identities.

crates/kosmo-synthesizer/src/patch_gates.rs, gate_patch, lines 58 onward:
  Mikro/Meso validation distinguishes patch consistency from synthesis ranking.
  This reference keeps gate permission independent of ranks and assessment.

crates/kosmo-agent/src/lib.rs, ValidationResult::dry_run, approximately lines
119--129, and dry-run positive-outcome test near line 984:
  Dry-run validation is represented by Warn and treated as positive feedback.
  This reference explicitly prevents dry_run evidence from certifying observed
  realization. A simulated successful proposal may remain useful for planning.

Repository identity and exact source provenance belong to the containing audit
bundle. These file locations describe inspected mechanisms, not a claim that this
reference reproduces or fixes Kosmocrates itself.
