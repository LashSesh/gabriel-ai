"""Execute the actual stdlib tests; save a small evidence and examples bundle."""
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import platform
import unittest

import kernel as k
import test_kernel

ROOT = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def examples():
    rows = []
    for domain in ("software", "documents", "numeric"):
        # Fixture only. These are NOT real domain observations or oracle runs.
        profile = k.Artifact((domain + "-fixture-profile").encode())
        oracle = k.Artifact((domain + "-fixture-oracle").encode())
        policy = k.Artifact(b"fixture-policy")
        input_blob = k.Artifact("synthetic input: \u00fc".encode("utf8"))
        params = k.Artifact(k.canonical({"fixture": True}))
        result = k.Artifact(b"fabricated pass record for contract exercise")
        g = k.goal(domain, profile.id, params.ref(), {"requirement": oracle.id})
        s = k.snapshot(domain, profile.id, {"input": input_blob.ref()}, 7)
        e = k.check_evidence(g.id, "requirement", s.id, oracle.id, profile.id,
                             "passed", "supported", "observed", result.ref())
        a = k.assess_goal(g, s, [e])
        c = k.candidate(g.id, s.id, "transform", input_blob.ref(), params.ref())
        d = k.gate_decision(c.id, g.id, s.id, policy.id, "permit")
        selected = k.select_candidate([c], [d], {c.id: 0}, g, s, policy.id)
        rows.append({"domain_label": domain, "fixture": True,
                     "assessment": a.json(), "selected_candidate": selected.id,
                     "records": [{"id": item.id, "body": item.json()}
                                 for item in (g, s, e, a, c, d)]})
    return {"status": "synthetic representation-portability fixtures only",
            "observed_field_note": "observed is a fabricated input label in these tests",
            "domains": rows}


def main():
    stream = io.StringIO()
    suite = unittest.defaultTestLoader.loadTestsFromModule(test_kernel)
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    report = {"executed_at_utc": datetime.now(timezone.utc).isoformat(),
              "python": platform.python_version(), "platform": platform.platform(),
              "command": "python3 run_checks.py", "tests_run": result.testsRun,
              "failures": len(result.failures), "errors": len(result.errors),
              "skipped": len(result.skipped), "passed": result.wasSuccessful(),
              "claim_scope": "pure contract behavior on synthetic fixtures; no agent or domain efficacy",
              "source_sha256": {name: sha((ROOT / name).read_bytes())
                                for name in ("kernel.py", "test_kernel.py", "run_checks.py")}}
    (ROOT / "checks.json").write_text(json.dumps(report, indent=2) + "\n")
    (ROOT / "checks.log").write_text(stream.getvalue())
    (ROOT / "examples.json").write_text(json.dumps(examples(), indent=2) + "\n")
    print(stream.getvalue())
    print(json.dumps(report, indent=2))
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
