"""Fresh narrow Store contract smoke check; run from the blueprint evidence directory.
No model, financial, native graph, market, or external tool effects are tested.
"""
from pathlib import Path
import copy
import hashlib
import json
import sqlite3
import sys
import tempfile

import argparse
parser=argparse.ArgumentParser(description='Probe the pinned recovered Gabriel runtime.')
parser.add_argument('--source', type=Path, required=True, help='Pinned repository checkout root')
parser.add_argument('--output', type=Path, required=True, help='New report file')
args=parser.parse_args()
ROOT=args.source.resolve()
sys.path.insert(0,str(ROOT))
from gabriel_runtime.engine import Store
from gabriel_runtime.fast_owner import FastStore
from gabriel_runtime.replay_owner import ReplayStore
from gabriel_runtime.canonical import canonical, loads

class Counter:
    def fingerprint(self): return {'adapter':'blueprint-counter/v1'}
    def initialize(self, config):
        if config!={}: raise ValueError('invalid config')
        return {'count':0}
    def apply(self, state, op, payload, at):
        if op!='add' or set(payload)!={'delta'} or type(payload['delta']) is not int: raise ValueError('invalid increment')
        state['count']+=payload['delta']
        return state,dict(state)
    def view(self,state): return dict(state)

def rejects(fn):
    try: fn()
    except ValueError: return True
    raise AssertionError('required rejection absent')

rows=[]
with tempfile.TemporaryDirectory(prefix='gabriel-blueprint-contract-') as directory:
    for owner in (Store,FastStore,ReplayStore):
        db=Path(directory)/(owner.__name__+'.sqlite')
        registry={'counter/v1':Counter()}
        with owner.create(db,registry) as s:
            bind={'id':'b','contract':'c','op':'bind','at':0,'expected_head':s.head,'payload':{'adapter':'counter/v1','config':{}}}
            s.submit(bind)
            add={'id':'a','contract':'c','op':'add','at':1,'expected_head':s.head,'payload':{'delta':3}}
            first=s.submit(add); original=canonical(first); before=copy.deepcopy(s.budget)
            assert canonical(s.submit(add))==original and s.budget==before
            retry=True
            changed=copy.deepcopy(add); changed['payload']['delta']=4
            conflict=rejects(lambda:s.submit(changed))
            stale=copy.deepcopy(add);stale['id']='stale'
            stale_rejected=rejects(lambda:s.submit(stale))
            assert s.view('c')=={'count':3} and s.budget==before
            anchor={'head':s.head,'events':s.budget['events']}
            s.audit(expected_head=anchor['head'],expected_events=anchor['events'])
        cross=[]
        for alternate in (Store,FastStore,ReplayStore):
            with alternate.open(db,registry,expected_head=anchor['head'],expected_events=anchor['events']) as reopened:
                assert reopened.view('c')=={'count':3}
                cross.append(alternate.__name__)
        wrong=rejects(lambda: owner.open(db,registry,expected_head='0'*64))
        rows.append({'owner':owner.__name__,'identical_retry':retry,'changed_retry_rejected':conflict,'stale_head_rejected':stale_rejected,'wrong_external_anchor_rejected':wrong,'cross_owner_full_replay':cross,'events':anchor['events']})
codec={'unicode_rejected':rejects(lambda:canonical({'text':'Grüße'})), 'float_rejected':rejects(lambda:canonical({'x':0.5})), 'duplicate_key_rejected':rejects(lambda:loads('{"x":1,"x":2}'))}
report={'status':'passed','scope':'Fresh synthetic runtime contract smoke check; no predictive or full-agent performance claim.','python':sys.version,'sqlite':sqlite3.sqlite_version,'owners':rows,'codec':codec,'source_sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (ROOT/'gabriel_runtime').glob('*.py')}}
out=args.output;out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'owners':len(rows),'cross_owner_replays':9,'codec_checks':len(codec)}))
