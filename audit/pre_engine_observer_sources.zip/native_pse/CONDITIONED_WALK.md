# Optional conditioned continuous-time graph walk

`pse_topology::conditioned_walk` is an explicit, additive API for the complete
complex state

\[
\psi(t)=\exp(-itL)\psi_0,\qquad L=D-A.
\]

The caller selects an initial state and can query it at many times. The existing
all-pairs CTQW statistics, default aliases, thresholds, and engine call sites do
not use this API. Its outputs are complex amplitudes, not legacy propagation
statistics or predictions. It is a classical numerical calculation, not a
quantum-hardware backend.

## Interface

```rust
use pse_topology::conditioned_walk::{
    BackendChoice, ConditionedWalkPlan, Complex,
};
use pse_topology::SparseLaplacian;

let graph = SparseLaplacian {
    n: 2,
    degree: vec![1.0, 1.0],
    adjacency: vec![(0, 1, 1.0), (1, 0, 1.0)],
};
let plan = ConditionedWalkPlan::new(&graph, BackendChoice::Auto)?;
let state = [Complex::new(1.0, 0.0), Complex::new(0.0, 0.0)];
let prepared = plan.prepare_state(&state)?;
let amplitudes = prepared.state_at(0.25)?;
# Ok::<(), pse_topology::conditioned_walk::WalkError>(())
```

`BackendChoice::Auto` recognizes a strict complete-graph special case, otherwise
uses a full eigendecomposition. `BackendChoice::Spectral` forces that same full
spectral implementation on every accepted graph and provides a matched baseline.
`plan.dimension()` and `plan.backend()` expose the actual choice; the latter is
`WalkBackend::CompleteGraph` or `WalkBackend::Spectral`.

The immutable plan owns its matrix representation, not the caller's graph. A
`PreparedState` borrows the plan and owns the original initial vector and its
state-specific mean or spectral overlaps. Mutating the original graph or state
after construction does not change the prepared calculation. No implicit graph
update, state update, truncation, normalization, stochastic process, or fallback
to a different dynamical model occurs.

## Accepted graph and state contract

- `n >= 1`, and the degree vector has exactly `n` entries.
- Degrees and weights are finite and nonnegative. Self-loops are rejected.
- Every supplied ordered pair `(i,j)` is unique and has an explicitly supplied,
  exactly equal reverse `(j,i)`. This also applies to explicit zero entries.
  Missing pairs represent zero weight. Negative zero equals positive zero.
- Each supplied degree must exactly equal the finite floating-point sum of its
  incident weights in increasing neighbour-index order. Adjacency input order
  does not affect this test. The API does not repair or tolerance-adjust degrees.
- Each initial state has exactly `n` finite complex entries. It need not have
  norm one; zero states and arbitrary finite norms are permitted. Squared norms
  are not computed during input validation, so a finite state is not rejected
  merely because its squared norm would overflow.
- Times may be positive, negative, or zero and must be finite. `t=0` returns the
  supplied finite state bit for bit after successful preparation. Singleton and
  edgeless graphs are supported.

The sign convention is the **positive** Laplacian with `exp(-itL)`. If weights
are dimensionless, time is dimensionless. If weights are angular frequencies,
time is in the corresponding reciprocal unit. Uniform nonnegative coupling is
encoded in the weights and degrees. There is no separate hidden coupling or
physical unit conversion; zero coupling gives an edgeless operator. This is not
the negative-Laplacian sign convention used in the inspected QSO Hamiltonian.

The current `compute_laplacian` producer accumulates incident edges in an order
compatible with increasing neighbour index, but external producers must satisfy
the declared contract themselves. Negative or invalid values previously clipped
by an upstream producer cannot be recovered or diagnosed by this API.

## Uniform complete-graph specialization

With `n` vertices, off-diagonal weight `w`, and a common stored diagonal `d`,
the actual matrix represented by these stored numbers has

\[
L=(d+w)I-w\mathbf1\mathbf1^\top,
\quad P=\mathbf1\mathbf1^\top/n.
\]

Its two eigenvalues are `lambda0 = d-(n-1)w` and `lambda1 = d+w`, yielding

\[
\psi(t)=e^{-it\lambda_0}P\psi_0+
 e^{-it\lambda_1}(I-P)\psi_0.
\]

For ideal arithmetic with `d=(n-1)w`, these reduce to zero and `nw`. The API
recognizes this case only when every stored off-diagonal weight is exactly equal,
all degrees are equal, and the stored degree also equals the rounded product
`(n-1)*w`. No approximate geometry or near-clique receives this specialization.
A valid uniform graph whose repeated degree sum differs from that product goes
through the full spectral backend. For example, `n=13,w=1.7` exercises that guard.

Even when the rounded-product check passes, the real number represented by `d`
can differ slightly from the exact real product of the stored binary64 weight.
`lambda0` is therefore computed by one fused multiply-add and is retained in the
evolution. Silently fixing this residual eigenvalue to zero would change the
actual matrix, which can become visible at large times. `lambda1` is computed
by floating-point addition. An edgeless Auto plan returns its initial state at
all finite times.

## Cost and numerical scope

Both choices validate and construct the dense matrix once in `O(n²+E)` time and
`O(n²)` temporary space. This makes construction comparable across backends and
avoids repeatedly searching the sparse edge list for each dense entry.

| Operation | Recognized complete graph | Full spectral backend |
|---|---:|---:|
| Plan construction | O(n²+E) | O(n²+E+n³) |
| Stored plan | O(1) beyond scalar metadata | O(n²) |
| Prepare one state | O(n) | O(n²) |
| Query its full state at one time | O(n) | O(n²) |
| Prepared state storage | O(n) | O(n) |

The spectral backend uses all `n` eigenpairs from nalgebra's `SymmetricEigen`;
no legacy truncated decomposition is inherited. It uses convergence tolerance
`f64::EPSILON` and iteration cap `max(1024,128*n)` (saturating multiplication),
then verifies finite eigenvalues and vectors. The implementation does not certify
eigenvector residuals or orthogonality; the independent numerical tests are
accuracy evidence for their tested cases, not a universal error bound.

The complete-graph formula is algebraically exact for the stated two-subspace
model. Its Rust implementation uses binary64 arithmetic and ordinary library
trigonometric functions. It is neither bitwise equivalent to a dense
eigendecomposition nor a rigorous rounding certificate. At very large times,
eigenvalue rounding amplified by time and trigonometric argument reduction can
lose accuracy. Very small entries can underflow; cancellation can increase
relative error. Finite outputs alone do not establish an accuracy guarantee.

Nonfinite intermediate phases, overlaps, means, eigenvalues, or final components
produce errors. An intermediate overflow is an error even when hypothetical
later cancellation would make the exact final result finite. A preparation error
occurs before any time query, including a prospective `t=0` query. No silent
renormalization or replacement kernel masks these errors.

## Verification and performance interpretation

The separate `conditioned_walk_tests.rs` covers independent matrix-power and
clique formulas, complex unnormalized states, sign, norm and inverse evolution,
degeneracy, zero time, singleton/edgeless cases, degree rounding, duplicate and
asymmetric entries, malformed dimensions, and overflow boundaries. Test presence
alone does not claim execution; the accompanying recorded command outputs state
what was actually run.

A fair performance comparison uses identical graphs, initial states, times,
complete complex outputs, and validation, separating plan construction, state
preparation, and repeated queries. An improvement here applies to this optional
conditioned query, not automatically to Gabriel's existing all-pairs engine,
decision quality, or end-to-end workload.
