#!/usr/bin/env python3
"""Fresh-extract TeX build QA; every generated output stays outside project."""
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess

PROJECT = Path('/tmp/gabriel_release_qa_g9d81q2k/extracted/Gabriel')
OUTPUT = Path('/tmp/gabriel_release_qa_g9d81q2k/tex_qa')
ENV = dict(os.environ)
ENV['TEXINPUTS'] = str(PROJECT) + '//:'
ENV['BIBINPUTS'] = str(PROJECT) + '//:'
REPORT = {
    'project': str(PROJECT),
    'output_directory': str(OUTPUT),
    'build_instructions': 'README.md lines 391-437: latexmk or pdflatex, bibtex, pdflatex twice',
    'build_policy': 'Two pdflatex passes use the archived main.bbl, with a third main pass if a reference rerun is still requested; no bibliography regeneration or source edit.',
    'visual_inspection': 'Delegated to parent; not performed in this QA task.',
    'expected_pages': {'main': 186, 'development_report': 3},
    'environment_overrides': {key: ENV[key] for key in ('TEXINPUTS', 'BIBINPUTS')},
    'commands': [],
    'documents': {},
}

def save_report():
    (OUTPUT / 'tex_qa_report.json').write_text(json.dumps(REPORT, indent=2) + '\n')

def run(command, label):
    record = {
        'label': label, 'argv': command, 'cwd': str(PROJECT),
        'shell_display': shlex.join(command),
        'stdout': str(OUTPUT / (label + '.stdout.txt')),
        'stderr': str(OUTPUT / (label + '.stderr.txt')),
    }
    with open(record['stdout'], 'wb') as stdout, open(record['stderr'], 'wb') as stderr:
        process = subprocess.run(command, cwd=PROJECT, env=ENV, stdout=stdout, stderr=stderr)
    record['returncode'] = process.returncode
    REPORT['commands'].append(record)
    save_report()
    print(json.dumps({'label': label, 'returncode': process.returncode}), flush=True)
    return process.returncode

def warnings(log):
    lines = log.splitlines()
    blocks = []
    for index, line in enumerate(lines):
        if re.search(r'(?:LaTeX|Package .*?|Class .*?) Warning:|Overfull \\[hv]box|Underfull \\[hv]box|^!', line):
            block = [line]
            for follow in lines[index + 1:index + 9]:
                if not follow.strip():
                    break
                block.append(follow)
            blocks.append('\n'.join(block))
    return blocks

for document, expected_pages in REPORT['expected_pages'].items():
    entry = {'expected_pages': expected_pages, 'passes': [], 'source': str(PROJECT / (document + '.tex'))}
    REPORT['documents'][document] = entry
    for pass_number in ((1, 2, 3) if document == 'main' else (1, 2)):
        label = f'{document}.pass{pass_number}'
        command = ['pdflatex', '-interaction=nonstopmode', '-halt-on-error', '-file-line-error', '-no-shell-escape', '-recorder', '-output-directory=' + str(OUTPUT), document + '.tex']
        returncode = run(command, label)
        pass_record = {'pass': pass_number, 'returncode': returncode}
        for extension in ('log', 'aux', 'out', 'fls'):
            generated = OUTPUT / (document + '.' + extension)
            if generated.exists():
                capture = OUTPUT / (label + '.' + extension)
                shutil.copyfile(generated, capture)
                pass_record[extension] = str(capture)
        if (OUTPUT / (document + '.log')).exists():
            log = (OUTPUT / (document + '.log')).read_text(errors='replace')
            pass_record['warning_blocks'] = warnings(log)
        entry['passes'].append(pass_record)
        save_report()
        if returncode:
            break
        if pass_number == 2 and not any('Rerun' in block or 'rerun' in block or 'Label(s) may have changed' in block for block in pass_record.get('warning_blocks', [])):
            break
    log_path = OUTPUT / (document + '.log')
    log = log_path.read_text(errors='replace') if log_path.exists() else ''
    entry['final_log'] = str(log_path)
    entry['final_warnings'] = warnings(log)
    entry['unresolved_citation_blocks'] = [block for block in entry['final_warnings'] if 'Citation' in block and 'undefined' in block]
    entry['unresolved_reference_blocks'] = [block for block in entry['final_warnings'] if 'Reference' in block and 'undefined' in block]
    entry['undefined_summary_blocks'] = [block for block in entry['final_warnings'] if 'undefined citations' in block or 'undefined references' in block]
    entry['rerun_warning_blocks'] = [block for block in entry['final_warnings'] if 'Rerun' in block or 'rerun' in block or 'Label(s) may have changed' in block]
    entry['overfull_boxes'] = re.findall(r'Overfull \\[hv]box[^\n]*', log)
    entry['underfull_box_count'] = len(re.findall(r'Underfull \\[hv]box', log))
    fls = OUTPUT / (document + '.fls')
    recorded_outputs = sorted(set(line[7:] for line in fls.read_text().splitlines() if line.startswith('OUTPUT '))) if fls.exists() else []
    entry['recorded_outputs'] = recorded_outputs
    entry['outputs_outside_qa'] = [name for name in recorded_outputs if not (Path(name) if Path(name).is_absolute() else PROJECT / name).resolve().is_relative_to(OUTPUT)]
    pdf = OUTPUT / (document + '.pdf')
    if pdf.exists():
        entry['pdf'] = str(pdf)
        entry['pdf_size_bytes'] = pdf.stat().st_size
        entry['pdf_sha256'] = hashlib.sha256(pdf.read_bytes()).hexdigest()
        run(['pdfinfo', str(pdf)], document + '.pdfinfo')
        info = (OUTPUT / (document + '.pdfinfo.stdout.txt')).read_text()
        match = re.search(r'^Pages:\s+(\d+)', info, re.M)
        entry['pages'] = int(match.group(1)) if match else None
        entry['expected_page_count_matches'] = entry['pages'] == expected_pages
    entry['passed'] = (len(entry['passes']) >= 2 and all(item['returncode'] == 0 for item in entry['passes']) and entry.get('expected_page_count_matches', False) and not entry['unresolved_citation_blocks'] and not entry['unresolved_reference_blocks'] and not entry['undefined_summary_blocks'] and not entry['rerun_warning_blocks'] and not entry['overfull_boxes'] and not entry['outputs_outside_qa'])
    save_report()

REPORT['source_sha256'] = {name: hashlib.sha256((PROJECT / name).read_bytes()).hexdigest() for name in ('main.tex', 'development_report.tex', 'main.bbl', 'references.bib')}
REPORT['main_source_matches_declared_editorial_delta'] = REPORT['source_sha256']['main.tex'] == '6aa16b9a881d61395f3cf0abc31bbeec98f394c3fba1ce7a1a0568bf8a600cc1'
REPORT['passed'] = all(entry['passed'] for entry in REPORT['documents'].values()) and REPORT['main_source_matches_declared_editorial_delta']
save_report()
(OUTPUT / 'commands.txt').write_text('\n\n'.join('cwd: ' + command['cwd'] + '\ncommand: ' + command['shell_display'] + '\nexit: ' + str(command['returncode']) + '\nstdout: ' + command['stdout'] + '\nstderr: ' + command['stderr'] for command in REPORT['commands']) + '\n')
print(json.dumps({'passed': REPORT['passed'], 'report': str(OUTPUT / 'tex_qa_report.json'), 'documents': {name: {key: value.get(key) for key in ('pages', 'passed', 'pdf', 'overfull_boxes', 'underfull_box_count', 'unresolved_citation_blocks', 'unresolved_reference_blocks', 'rerun_warning_blocks', 'outputs_outside_qa')} for name, value in REPORT['documents'].items()}}, indent=2), flush=True)
