# Runtime extraction and integration provenance

The operational runtime is a new compositional implementation hosting existing
Gabriel numerical/domain algorithms. The English manuscript is the scientific
description; this file records development provenance and audit scope.

## Supplied source

The user supplied `ophan_bridge-main.zip`, whose root README identifies the
GRFPS second-layer perception profile 0.30.0. Source archive SHA-256:

`653ea8ef5cb23532675fd6a4336c16ea6b7988a68e08fccd921164b5a82784bc`

The archive contains 3,945 files and 944,305,168 uncompressed bytes, largely saved
JSON/JSONL histories and generated HTML. All 280 Python files, including nested
source copies, were mechanically parsed (23,611 lines; no syntax errors). This
inventory is not a claim that every line, every generated history or all attached
publications were semantically reviewed. The focused architecture audit names
the files and contracts actually examined.

## What was extracted

| Source mechanism | New runtime realization | Boundary |
|---|---|---|
| Pure candidate reducer and publish-after-journal | Local adapter interface and atomic SQLite command/state/result/log transaction | Local trusted code; no distributed consensus or external effects |
| Exact schema and canonical records | Strict ASCII exact JSON; duplicate-key rejection; canonical-byte retry identity | Hexadecimal binary64 encoding preserves representation, not real-arithmetic accuracy |
| Scoped evidence and current-view invalidation | Immutable per-module contract and explicit domain semantic profiles | No universal equation of physical truth, finite-model decision and forecast validity |
| Replay of state transitions | Recompute every transition, state hash, result and receipt | Reuses declared reducers; not an independent proof of their mathematics |
| Version/source binding | Relevant source fingerprints and fixed adapter registry | No authentication of a device or honest execution environment |
| Bounded accepted history | Owner event/byte limits and per-adapter operation caps | No CPU, throughput or hard real-time guarantee |
| Historical prefix replay | Optional expected terminal head and event-count anchor | The retained anchor itself requires trust |

The current upstream bank chain has 18 classes. It was not copied into Gabriel.
XR geometry, instrument calibration, browser transport and the generated galleries
remain source-domain components. They do not provide a financial predictor.

Two upstream boundary examples informed concrete checks: the historical Boolean
kernel compares retry dictionaries using Python equality (`True == 1`), and a
valid complete journal prefix remains internally replayable after deleting a whole
suffix. The new implementation uses canonical identity and supports separately
retained completeness anchors. The latter is a scope limit of internal replay,
not a claim that hashing alone can authenticate history.

## Direct reuse from Gabriel

The adapters import these existing local sources without modifying them:

- `finite_observation.py`
- `decision_regions.py`
- `sequential_contract.py`
- `maturity_ledger.py`
- `ecb_risk.py`
- `replay_adaptive_maturity.py`

The new adapter adds strict ingress validation, finite derived-score checks and
distinct declared-receipt versus historical-import issuance rules. The risk
controller is an execution reference from the existing research, not a newly
selected or recommended predictor. Forecasts and initial checkpoints are supplied;
this runtime slice does not generate an entire market strategy.

## Executed validation and retained evidence

`results/runtime_checks.json` records the fresh integration tests, their synthetic
inputs, source hashes, exact comparison rules and explicit non-tested scope.
`results/runtime_history_replay.json` records the archived financial preservation
study. `results/runtime_cli_checks.json` records the actual CLI subprocess checks.
The runtime demo is retained in `results/runtime_demo.json`; it uses synthetic
inputs and is regenerated through the supplied CLI.

`results/ophan_upstream_audit.json` records the fresh original 0.30 release gate:
1,026 Python tests and 937 JavaScript checks, semantic replay of 3,450 retained
transitions, and a separately executed CLI restart with two owner and three
producer processes. Historical producer/HTTP reports were not reexecuted, and no
headset, physical instrument or visual browser evaluation occurred. The source
gate ran in an isolated copy; all 276 top-level original Python files remained
unchanged. Additional scoped probes are recorded separately.

The upstream archive is identified above and remains the user's supplied source;
it is not vendored into the cleaned runtime or required to execute it. Repeating
the upstream release gate requires that original archive. Every dependency source
needed for the delivered runtime demo and integration checks is included. Python,
SQLite and declared numerical packages remain environment dependencies. The
complete research project retains the historical benchmark data; the compact
runtime distribution omits those archives and the historical replay driver.

## Literature and status

Event/processing-time distinctions follow established stream-processing work;
SQLite supplies transaction machinery. The paper cites primary Dataflow research
and official SQLite documentation. This implementation claims concrete component
preservation and tested fault handling. It does not claim priority for event
sourcing, transaction logs, idempotency or modular adapters, or improved predictive
accuracy. The current two-adapter migration is explicit; other Gabriel modules
remain in the research project pending their own integration contracts.

## Generated-stream integration

The subsequent stream profile closes an input-to-generated-forecast loop in
`gabriel_runtime/stream.py`. Its sources are the unchanged `ecb_risk.py`,
`severity_risk.py` and `aggregate_risk.py` implementations and the preceding
transaction owner. The new adapter invokes the base generator and projection/
scoring routines, and specializes severity and cumulative feedback into a fold
against immutable issued records. The correction-aware fold is newly implemented;
its regular uncorrected execution is compared with the original batch routines.
The existing numerical sources, `engine.py`, `canonical.py` and `adapters.py`
remain unchanged. The CLI adds an explicitly selected `stream` registry while
retaining the original default profile and source bindings.

Every new source index triggers feedback maturation followed by attempted forecast
generation. Both expert banks and aggregate weights are generated from received
records; no externally supplied forecasts enter this profile. Model-positive
forecast unavailability is explicit, and the originally positive scoring domain
is retained. The eight-expert bank uses the existing base, two severity memories
and cumulative aggregate at scale 0.1. This is an integration profile, not a new
parameter selection or a claim that the previously failed superiority criterion
has been satisfied.

A corrected source value changes current feedback and future inference; it does
not regenerate the original issue tape. A newly derived, conditional score bound
retains the signed difference between the gradient's original evaluation state
and the current replay state. The argument specializes standard convexity and
projection machinery. The explicit two-expert stale-evaluation counterexample
shows why discarding that term is invalid. It is a constructed mathematical
sequence, not an asserted reachable market trajectory.

Observation indexes are distinct from event and receipt timestamps. The temporal
basis is `next_unreceived_observation`; after maturity the result also reports
`target_after_issue`. Delayed ingestion may concern an event already completed
outside the store. This scope was identified during independent final review and
made explicit in the code, tests and manuscript. It is not a guarantee of genuine
future-event forecasting or authenticated source vintages.

The read-only exposure proposal uses an exact rational comparison of the dyadic
number represented by binary64 ES. It maximizes integer units under a declared
per-proposal log-loss proxy budget. It does not provide portfolio reservation,
external execution, realized-loss control or a rounding certificate for estimated
risk.

Fresh execution records are `results/stream_checks.json`,
`results/stream_history_replay.json` and `results/stream_cli_checks.json`.
The historical study uses only the original four currency columns and initializes
at the first eligible source prefix. It does not reuse the 2010 learner checkpoint
or introduce another market-selection experiment. The full original corpus is
retained; its older complete training runs are not repeated for this change.
The small runtime package includes the synthetic test closure and now requires
NumPy and SciPy; it omits the historical raw archive and replay driver.


## Incremental execution of the preserved stream contract

`incremental.py` adds an explicitly selected alternative evaluator for the existing `stream-risk/v1` semantics. The original owner, canonicalizer, research adapters, `stream.py`, and eight hosted research modules are unchanged. CLI profile selection and the synthetic demo helper are extended; default legacy/reference outputs remain checked.

The new evaluator reuses verified variance prefixes and immutable-issued feedback contributions, computes only the current six tail rows, replays affected aggregate lanes and the globally ordered severity suffix, and preserves historical finite-domain guards. Its cache is private, bounded, disposable and absent from accepted source state. Numerical equivalence is conditional on the fixed machine operations/environment and supported by executed exact-byte comparisons, not a machine-checked Python proof.

Executed independent checks are in `results/incremental_checks.json`; separate command-line checks and the generated example are in `incremental_cli_checks.json` and `incremental_demo.json`. The synthetic efficiency study retains `incremental_benchmark_protocol.json`, `incremental_benchmark_inputs.json`, `incremental_benchmark.json` and the executable driver. It compares both full trajectories and repeated terminal cases, including correction-then-append bundles so deferred variance repair is measured. A pre-timing protocol revision added those bundles and selected an early issued endpoint; no measured outcome informed it. No new market data, predictive parameter selection or reserved currency evaluation occurred.

The study demonstrates less repeated numerical work and measured speed gains in bounded synthetic histories. It also exposes persistent full-history array construction, canonical materialization and journal costs. Wall-clock repetitions include slower individual incremental cases; paired medians and full raw samples are retained rather than asserting uniform or production-wide speedup. The standard memoization/change-propagation idea is attributed; correction locality and the specific reference-equivalence argument are derived in the manuscript. See the separate review notes in `audit/` for access and verification scope.


## Equivalent owner materialization and the supplied PSE archive

The supplied `pse-standalone.zip` (SHA-256 `30d4a6aeab6c6509c0cc31fcf5b4be4fd3f95aec745127aa848c8ce37b7299ca`) is preserved at `audit/pse-standalone.zip`. It is a synchronous Rust graph-analysis pipeline, not an implementation of the durable Gabriel owner. Original archive metadata, scoped source reviews, actual build outcomes and counterexamples are retained separately. The earlier unpublished `_pse_forensics/` originals and comparison binaries referenced in its documents were not supplied or inspected.

Its useful execution principle is applied to Gabriel in `fast_owner.py`: remove repeated materialization while preserving an explicit reference. Checked structural copies preserve exact types, values, nested dictionary iteration order and mutable isolation for value-based adapters. Locally validated state text is reused for state hashing and storage. The original owner, exact codec, adapters, stream implementation, incremental implementation and eight research dependencies remain unchanged. There is no cross-call owner-state cache, weakened durability, grouped commit or skipped semantic audit. Registry profile and owner selection are independent; both owners deliberately use the same journal protocol and fingerprints. The new owner source is identified in release manifests and executed reports rather than falsely claimed to be bound by the unchanged original header.

This equivalence is conditional on stable data inputs, adequate resources and adapters that depend on values and container order. An executed Python scalar-identity counterexample documents the excluded introspection behavior. Independent checks compare complete stored rows and canonical receipts, exercise malformed data and process failures, and open each owner's store with the other. The new benchmark uses the already incremental numerical adapter on both sides, with its own retained synthetic seed and no new market evaluation. Its ratios cannot be multiplied with the previous experiment's ratios as an unmeasured combined speed claim.

The optional `native_pse/` fork retains its MIT license, all original mathematical routines and historical fixture. Its small-region signature path uses exact packed permutations and avoids discarded scan work. It remains an auxiliary graph-analysis source; it is not linked into the Python owner or financial reducers. The finite signature proof and same-environment comparisons do not repair inherited heuristic or numerical claims. In particular, retained wall-clock branches prevent an unrestricted whole-engine determinism claim. The original cross-environment fixture disagreement remains visible, with cause unresolved. Begin with `native_pse/GABRIEL_REVIEW.md`, not an assumption that historical logs are new executions.
