# Gabriel: Contractive Dynamics, Temporal Memory and Selective Observation

Sebastian Klemm

Research materials for the accompanying manuscript: a sparse recurrent architecture
with bounded activities, local correlation traces, event and elapsed-time memory,
and conditional decisions from incomplete observations. The decision infrastructure
includes exact rational finite-scenario risk calculations, absolute action constraints
and selective retrieval of current records. Gabriel cells name the local recurrent units.

## Owner execution

All CLI commands accept `--owner reference|fast`; `reference` remains the default.
The `fast` owner reduces redundant canonical JSON materialization for the same
trusted adapters operating on JSON values. It preserves the journal format,
adapter fingerprints, one-transaction command boundary and complete semantic
replay on open. Owner choice is independent of `--profile`.
Stores can alternate owners without migration; their adapter profile must still
match the immutable registry binding.

```bash
python -m gabriel_runtime incremental-demo --out fast-run --owner fast
python -m gabriel_runtime audit fast-run/owner.sqlite --profile incremental --owner reference --anchor fast-run/anchor.json
python -m gabriel_runtime inspect fast-run/owner.sqlite --profile incremental --owner fast --contract stream
python reproduction/check_fast_owner_cli.py
```

`gabriel_runtime/FAST_OWNER.md` describes the execution contract and its scope.
The CLI comparison exercises both owners across all three profiles, exact demo
journals and anchors, cross-owner updates and retries, and failed submissions.
This execution choice does not change the forecasting model or predictive policy.

## Incremental execution

The incremental profile preserves the reference stream's domain states and outputs while reusing derived variance and feedback work. Its execution fingerprint is explicit; an existing reference-profile store remains bound to its original profile.

```bash
python -m gabriel_runtime incremental-demo --out incremental-run
python -m gabriel_runtime audit incremental-run/owner.sqlite --profile incremental --anchor incremental-run/anchor.json
python reproduction/check_incremental.py
python reproduction/check_incremental_cli.py
```

Schemas, cache dependencies and scope are in `gabriel_runtime/INCREMENTAL.md`. The verification includes exact state/result comparisons, revisions, cache disposal, rewind/fork behavior and historical arithmetic failures. The separate synthetic efficiency study retains its input prices, protocol, raw timings and operation counts. Reproduce its measurements in a quiet environment with:

```bash
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 python reproduction/benchmark_incremental.py --run
python reproduction/plot_incremental.py
```

These shell environment assignments use POSIX syntax. The recorded execution uses the pinned Python environment; dependency installation is separate. Timing reproduction is descriptive and can vary across systems. Full-history array construction, canonicalization and journaling remain; the optimization changes execution work, not the predictive policy.

## Integrated runtime

The `stream` profile generates an eight-expert risk forecast from received positive
scalar observations and learns when its target observation arrives. Corrections
replay current learning against the originally issued banks and weights; published
forecasts and read-only model-budget proposals stay immutable.

```bash
python -m gabriel_runtime stream-demo --out stream-run
python -m gabriel_runtime audit stream-run/owner.sqlite --profile stream --anchor stream-run/anchor.json
python -m gabriel_runtime inspect stream-run/owner.sqlite --profile stream --contract stream
python reproduction/check_stream.py
python reproduction/replay_stream_history.py
```

The exact profile is documented in `gabriel_runtime/STREAM.md`. Its horizon counts
new observations, not calendar time. For delayed ingestion the next unreceived
target may already have occurred outside the store; mature records explicitly
report that temporal relationship. The proposal limits a declared log-loss proxy
for one issue, not realized losses or a portfolio's total commitments. It executes
no order. The source and numerical parameters are fixed in the contract.

The original two-adapter profile remains the default, with the same bound
implementation files. Use `--profile stream` explicitly for stores created with
the extended registry; registry profiles are never guessed from untrusted code.


The original profile supplies one transactional owner for finite
observation and target-maturity feedback. From the project directory:

```bash
python -m gabriel_runtime demo --out local-run --with-conflict
python -m gabriel_runtime audit local-run/owner.sqlite --anchor local-run/anchor.json
python -m gabriel_runtime inspect local-run/owner.sqlite --contract risk
python reproduction/check_runtime.py
python reproduction/replay_runtime_history.py
```

The demo uses synthetic inputs, saves the original commands, SQLite database,
semantic journal, terminal anchor and result summary, and refuses to overwrite an
existing store. `python -m gabriel_runtime --help` lists command submission,
inspection, export and audit. Exact schemas and restrictions are in
`gabriel_runtime/CONTRACT.md`. Historical-import statements are explicitly marked;
no API call places a trade or controls an XR device.

The smaller `Gabriel_Runtime.zip` distribution contains this same runtime, its
eight local dependency modules, the synthetic integration checks and pinned
NumPy/SciPy requirements. It does not include the historical financial data or the
historical replay drivers. The complete research ZIP remains the full reproducible
manuscript and benchmark distribution. Extraction scope and upstream test evidence
are recorded in `RUNTIME_PROVENANCE.md` and `audit/`.


## Optional native graph analysis

`native_pse/` contains the reviewed PSE source and an equivalent packed implementation of its bounded small-graph signature. Begin with [`native_pse/GABRIEL_REVIEW.md`](native_pse/GABRIEL_REVIEW.md). The original supplied archive, focused source review, actual counterexamples and current measurements are retained. The native kernel is not called by the Python owner or financial reducers.

Current Linux builds retain an unresolved mismatch with one supplied historical fixture. The explicit test exclusion and the otherwise passing 433/438-test runs are documented; the fixture was not replaced to conceal this result. Inherited heuristic, spectrum and topology limitations also remain visible. The bounded signature optimization has separate exact tests and a matched benchmark; its large eligible-path gains do not apply to ordinary ingestion or durable Gabriel processing.

The full project includes source, lockfiles and portable reconstruction commands. Rust 1.95.0 and the declared Cargo dependencies are external build requirements. The compact Python runtime does not need them. Historical documents and Windows measurements inside the native tree retain their original provenance; current results are under `native_pse/benchmark-results/gabriel/`.

## Contents

- `main.tex`, `references.bib`, `main.bbl`: manuscript and bibliography.
- `reproduction/`: model implementations, input generators, benchmarks and verification programs.
- `data/`: original train/test files for four public classification datasets, the unchanged ECB reference-rate archive and CSV, attribution and provenance.
- `results/`: experimental protocols, fitted models, inputs, predictions, acquisition paths,
  exact certificates, numerical checks and generated manuscript tables.
- `figures/`: vector figures and raster previews used in the manuscript.
- `REFERENCES.tsv`: bibliographic source checks, access scope and access dates for all 86 cited works.
- `requirements.txt`: pinned Python dependencies.
- `SHA256SUMS.txt`: SHA-256 checksums for every other packaged file.
- `build_release.py`: rebuilds the distribution and checks ZIP integrity.

The manuscript PDF is a separate file. All project-specific inputs required to
build it and reproduce the studies are contained in this archive. Standard Python
packages and a LaTeX distribution are installed separately as described below.

## Scientific scope

The joint activity/trace contraction condition is sufficient, not necessary.
Local execution assumes fair updates and bounded message age. Event-index storage,
ordered fading memory and damped phase banks implement different temporal contracts.
State budgets count mathematical real coordinates, not Python storage bytes.

The four external classification datasets are RacketSports, BasicMotions, NATOPS
and Epilepsy. Performance and acquisition cost depend on the task and observation
mask. Epilepsy contains movement by healthy participants and seizure-mimicking
activity; it is not clinical EEG. The experiments do not establish general
classification superiority or an optimal universal state dimension.

Acquisition retrieves values from an immutable buffered record. Input-box bounds
preserve a fixed model's decision when their assumptions hold; this is separate
from correctness against external class labels. The nonlinear observer's continuous
box pipeline uses float64 enclosures with explicit numerical tolerances. Arb
validates the identified point decisions and the standalone linear temporal banks'
continuous-box decisions. These scopes must not be interchanged.

The finite-history and annular orientation studies are exact, synthetic mechanism
studies. Under one arbitrary persistent report error, the annular adaptive policy
uses 12--17 of 24 reports; every universally sufficient fixed query set contains
all 24 coordinates. The complete 102400-case catalogue is included for each policy.
The five-query continuation is optimal after the specified two-ring prefix; global
optimality over all possible adaptive prefixes is not claimed. The implemented
EC2 baseline attains the same query counts. An invalid model or error budget can
invalidate a decision, as the supplied counterexamples demonstrate.

The financial adapter is a synthetic, exhaustive mechanism study: 64 distinct current
books appear twice with an irrelevant tag. Exact convex-mixture CVaR witnesses and
the common acceptable-action rule are independently verified. Risk modeling and
decision-region determination are established methods, specialized here to an
immutable-record contract. The primary optimal worst acquisition cost is 9 versus
10 for minimum static full-book recovery. Reversed query order also attains 9 and
has a better uniform mean. This finite-book study reports no market return, live trade or Aladdin performance
comparison. The separate ECB study below evaluates historical risk forecasts. A second
industrial adapter uses the same action engine.

## Reproduce only the risk and action studies

The core new modules use the Python standard library and exact `Fraction` arithmetic.
The optional linear-program diagnostic uses SciPy; plotting uses Matplotlib.
From the project directory:

```bash
python reproduction/check_portfolio_risk.py
python reproduction/check_decision_regions.py
python reproduction/benchmark_portfolio.py
python reproduction/verify_portfolio_outputs.py
python reproduction/summarize_portfolio.py
```

These commands generate `portfolio_risk_checks.json`, `decision_region_checks.json`,
`portfolio_results.json`, `portfolio_verification.json`, the summary tables and the
acquisition figure. The verification program does not call the risk optimizer.
The frozen protocol digest is enforced by `portfolio_adapter.py`.

## Versioned risk forecasts and budgeted acquisition

The budgeted planner minimizes mean acquisition cost under an explicit pathwise
cap. Its primary synthetic mean is 45/8=5.625 at unchanged worst cost 9. Versioned
event/receipt snapshots and exact risk-change bounds support conditional renewal
of action certificates; a failed sufficient gate requests recomputation.

The empirical financial study uses the unchanged official ECB reference-rate
archive. Development is 2010--2019; testing is 2020--2025. Four currencies and two
horizons yield 61,400 reported forecast pairs. The fixed two-scale variance filter
beats raw historical simulation on mean FZ0 in 8/8 comparisons, but the fast
single-scale filter beats that combination in 6/8. Calibration discrepancies
remain. Reference rates are informational, not executable quotes; this current
snapshot does not recreate historical publication vintages. There is no trading
or investment-performance claim. ECB inputs retain their own terms, documented
in `data/ECB_ATTRIBUTION.md`.

Run only this extension from the project root:

```bash
python reproduction/check_budgeted_regions.py
python reproduction/benchmark_budgeted_regions.py
python reproduction/verify_budgeted_regions.py
python reproduction/summarize_budgeted_regions.py
python reproduction/check_sequential_contract.py
python reproduction/benchmark_ecb_risk.py
python reproduction/verify_ecb_risk.py
python reproduction/summarize_ecb_risk.py
python reproduction/forecast_ecb_snapshot.py
python reproduction/check_ecb_snapshot.py
```

The snapshot driver defaults to 23 December 2025 and produces 8 model-bound risk
forecast records from the retained data prefix. Use `--date YYYY-MM-DD` to choose
another available origin. It uses the primary fixed equal-weight filter;
binding a forecast to its data/model identity is separate from proving numerical
rounding or action acceptability. All new forecast and selection outputs are
checked by an independent extended-precision implementation.

## Environment

The experiments used Python 3.12.14 and the versions pinned in `requirements.txt`:
NumPy 2.3.5, SciPy 1.17.0, Matplotlib 3.10.8 and python-flint 0.9.0.

```bash
python -m pip install -r requirements.txt
```

For comparable CPU execution, set `OPENBLAS_NUM_THREADS=1` and `OMP_NUM_THREADS=1`
using the syntax of your shell before running the programs. All dataset files are
included; reproduction needs no network access after dependency installation.
Execution time depends on the selected study, hardware and numerical libraries.

## Outcome maturity and adaptive calibration

The new feedback interface retains immutable issued forecasts and one active
score per matured target. Both event completion and receipt availability are
required. Revisions replace a score and replay the learner; they do not add an
independent training observation. The accepted-operation prefix disambiguates
operations with identical timestamps.

The clipped log-scale controller uses exact rational state and signed projection
accounting, conditional on binary64 forecast comparisons. It targets breach
frequency, not joint VaR/ES score or conditional calibration. In the retrospective
2020--2025 comparison the primary rule improves frequency discrepancy in 5/8
contracts and joint score in 2/8. On the previously unused short 2026 extension,
it improves frequency discrepancy in 2/8 and joint score in 0/8. All candidates,
static controls and negative findings are retained. The seven models share 1480
extension targets (10360 reported forecast pairs), not independent samples.

Run this extension from the project root:

```bash
python reproduction/check_maturity_ledger.py
python reproduction/check_calibration_accounting.py
python reproduction/benchmark_adaptive_risk.py
python reproduction/verify_adaptive_risk.py
python reproduction/summarize_adaptive_risk.py
python reproduction/replay_adaptive_maturity.py
python reproduction/check_severity_objective.py
python reproduction/check_severity_correction.py
python reproduction/benchmark_severity_risk.py
python reproduction/summarize_severity_risk.py
python reproduction/verify_severity_risk.py
python reproduction/replay_severity_maturity.py
python reproduction/check_aggregation_math.py
python reproduction/check_aggregate_summary.py
python reproduction/screen_aggregate_development.py
python reproduction/benchmark_aggregate_risk.py
python reproduction/summarize_aggregate_risk.py
python reproduction/verify_aggregate_risk.py
python reproduction/diagnose_aggregate_risk.py
python reproduction/verify_aggregate_diagnostics.py
python reproduction/verify_forgetting.py
python reproduction/verify_forgetting_summary.py
python reproduction/benchmark_forgetting_market.py
```

`adaptive_risk_protocol.json` fixes the source, parameter grid and period roles.
The independent verifier reuses the previously checked parent forecasts and
reconstructs every new adaptive/static pair. `replay_adaptive_maturity.py` checks
all 1480 extension targets against the generic ledger using raw rate endpoints
and explicit per-lane checkpoints. Its eight endpoint corrections are synthetic
mechanism tests; source files and issued forecasts remain unchanged.

## Build the manuscript

From the project directory, with pdfLaTeX, BibTeX and latexmk available:

```bash
python reproduction/check_portfolio_risk.py
python reproduction/check_decision_regions.py
python reproduction/benchmark_portfolio.py
python reproduction/verify_portfolio_outputs.py
python reproduction/summarize_portfolio.py
python reproduction/check_budgeted_regions.py
python reproduction/benchmark_budgeted_regions.py
python reproduction/verify_budgeted_regions.py
python reproduction/summarize_budgeted_regions.py
python reproduction/check_sequential_contract.py
python reproduction/benchmark_ecb_risk.py
python reproduction/verify_ecb_risk.py
python reproduction/summarize_ecb_risk.py
python reproduction/forecast_ecb_snapshot.py
python reproduction/check_ecb_snapshot.py
python reproduction/check_maturity_ledger.py
python reproduction/check_calibration_accounting.py
python reproduction/benchmark_adaptive_risk.py
python reproduction/verify_adaptive_risk.py
python reproduction/summarize_adaptive_risk.py
python reproduction/replay_adaptive_maturity.py
python reproduction/check_severity_objective.py
python reproduction/check_severity_correction.py
python reproduction/benchmark_severity_risk.py
python reproduction/summarize_severity_risk.py
python reproduction/verify_severity_risk.py
python reproduction/replay_severity_maturity.py
python reproduction/check_aggregation_math.py
python reproduction/check_aggregate_summary.py
python reproduction/screen_aggregate_development.py
python reproduction/benchmark_aggregate_risk.py
python reproduction/summarize_aggregate_risk.py
python reproduction/verify_aggregate_risk.py
python reproduction/diagnose_aggregate_risk.py
python reproduction/verify_aggregate_diagnostics.py
python reproduction/verify_forgetting.py
python reproduction/verify_forgetting_summary.py
python reproduction/benchmark_forgetting_market.py
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

Alternatively, run `pdflatex main.tex`, `bibtex main`, and then
`pdflatex main.tex` twice. Figures, generated tables and bibliography inputs are
included; no external manuscript files are required. Paragraph indentation is
zero and paragraph spacing is provided by `parskip`.

## Check the delivered archive and saved evidence

On systems with GNU coreutils, verify the unpacked files before running programs:

```bash
sha256sum --check SHA256SUMS.txt
```

The following programs independently replay three principal evidence sets without
retraining the full collection of models:

```bash
python reproduction/verify_orientation.py
python reproduction/verify_robust_orientation.py
python reproduction/verify_phase_outputs.py
```

Other study-specific `check_*.py` and `verify_*.py` programs appear in the complete
sequence below. Point and box validation involving Arb requires python-flint.
Selected phase comparisons can be repeated at higher precision with
`python reproduction/verify_phase_outputs.py --precision 160`.
An unresolved numerical comparison does not issue a certificate.

Programs write their corresponding result files. Use a fresh extracted copy when
rerunning studies so that the delivered outputs and checksum manifest remain
available for comparison. Runtime fields and PDF timestamps may change;
byte equality is not a general criterion for numerical reproducibility.

## Complete reproduction sequence

Run these commands from the project directory in the order shown. The sequence
regenerates the scientific studies and builds the manuscript from their outputs.
Protocols, seeds, initial states, splits and tolerances are recorded in the code
and the corresponding `results/*protocol.json` and verification files. Original
and reduced finite-domain studies, negative results and deliberate model violations
are retained. Some comparisons were designed after inspecting earlier cohorts;
that distinction is documented in the manuscript and saved protocols.

```bash
python reproduction/run_experiments.py
python reproduction/memory_extension.py
python reproduction/check_composition.py
python reproduction/check_async.py
python reproduction/make_figures.py
python reproduction/check_multitime.py
python reproduction/benchmark_multitime.py --cohort discovery
python reproduction/benchmark_multitime.py --cohort routing
python reproduction/verify_multitime_outputs.py
python reproduction/plot_multitime.py
python reproduction/check_partial.py
python reproduction/benchmark_partial.py
python reproduction/verify_partial_outputs.py
python reproduction/plot_partial.py
python reproduction/check_scalable.py
python reproduction/benchmark_external.py
python reproduction/verify_external_outputs.py
python reproduction/check_delayed.py
python reproduction/plot_external.py
python reproduction/check_observer.py
python reproduction/benchmark_observer.py
python reproduction/verify_observer_outputs.py
python reproduction/summarize_observer.py
python reproduction/probe_relaxed.py
python reproduction/check_relaxed.py
python reproduction/benchmark_relaxed.py
python reproduction/verify_relaxed_outputs.py
python reproduction/check_validated.py
python reproduction/benchmark_witnesses.py
python reproduction/benchmark_blocks.py
python reproduction/benchmark_block_control.py
python reproduction/verify_decision_records.py
python reproduction/summarize_decisions.py
python reproduction/check_prefix.py
python reproduction/benchmark_prefix.py
python reproduction/verify_prefix_outputs.py
python reproduction/summarize_prefix.py
python reproduction/check_domain.py
python reproduction/benchmark_domain.py
python reproduction/verify_domain_outputs.py
python reproduction/summarize_domain.py
python reproduction/check_phase.py
python reproduction/benchmark_phase.py
python reproduction/verify_phase_outputs.py
python reproduction/summarize_phase.py
python reproduction/benchmark_orientation.py
python reproduction/verify_orientation.py
python reproduction/summarize_orientation.py
python reproduction/benchmark_robust_orientation.py
python reproduction/verify_robust_orientation.py
python reproduction/summarize_robust_orientation.py
python reproduction/check_portfolio_risk.py
python reproduction/check_decision_regions.py
python reproduction/benchmark_portfolio.py
python reproduction/verify_portfolio_outputs.py
python reproduction/summarize_portfolio.py
python reproduction/check_budgeted_regions.py
python reproduction/benchmark_budgeted_regions.py
python reproduction/verify_budgeted_regions.py
python reproduction/summarize_budgeted_regions.py
python reproduction/check_sequential_contract.py
python reproduction/benchmark_ecb_risk.py
python reproduction/verify_ecb_risk.py
python reproduction/summarize_ecb_risk.py
python reproduction/forecast_ecb_snapshot.py
python reproduction/check_ecb_snapshot.py
python reproduction/check_maturity_ledger.py
python reproduction/check_calibration_accounting.py
python reproduction/benchmark_adaptive_risk.py
python reproduction/verify_adaptive_risk.py
python reproduction/summarize_adaptive_risk.py
python reproduction/replay_adaptive_maturity.py
python reproduction/check_severity_objective.py
python reproduction/check_severity_correction.py
python reproduction/benchmark_severity_risk.py
python reproduction/summarize_severity_risk.py
python reproduction/verify_severity_risk.py
python reproduction/replay_severity_maturity.py
python reproduction/check_aggregation_math.py
python reproduction/check_aggregate_summary.py
python reproduction/screen_aggregate_development.py
python reproduction/benchmark_aggregate_risk.py
python reproduction/summarize_aggregate_risk.py
python reproduction/verify_aggregate_risk.py
python reproduction/diagnose_aggregate_risk.py
python reproduction/verify_aggregate_diagnostics.py
python reproduction/verify_forgetting.py
python reproduction/verify_forgetting_summary.py
python reproduction/benchmark_forgetting_market.py
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

After building `main.pdf`, `python build_release.py` recreates the publication ZIP
and copies the PDF beside it. This packaging step checks every NPZ container and
the resulting ZIP, and regenerates the checksum manifest.

## Severity adaptation

The severity adapter maintains an **uncapped** discounted sufficient statistic
and caps only the emitted ES/VaR ratio. Its reciprocal-ratio objective is convex;
the retained state gives an exact real-arithmetic historical minimizer, not a
future calibration guarantee. All severity market comparisons, including 2026, are
retrospective because those outcomes were already examined. The separate frozen
known-law study has five cases, 32 replications and two receipt latencies. Latency
five delays an individual synthetic outcome and does not aggregate five losses.
Every replication's metrics and full replicate-zero traces are retained; seeds
and code reconstruct the other full traces. Run the severity commands above
to reproduce this study and its maturity/correction checks. Arithmetic is binary64
with separately documented verification tolerances. Older training runs were not
reexecuted for this extension.

## Convex joint-risk aggregation

The joint-risk layer mixes `(Q/E, 1/E)` on a simplex. Its Jensen identity proves
an outcome-wise advantage over randomized expert selection with the same weights.
It does not promise to beat the best deterministic expert. A frozen positively
regularized empirical objective has a unique proximal fixed point; the actual
numerical fitting routine uses SLSQP and is checked against a convex lower bound.
Online simplex updates use separate maturity lanes and centered gradients.

`results/aggregate_risk_protocol.json` and its `.sha256` seal freeze the primary
method before any new-currency evaluation. USD/GBP/JPY/CHF through 2019 selected
`adagrad_c0p1`; the screen now writes a separately named replay result and cannot
overwrite the frozen original. AUD/CAD/NOK/SEK are previously unevaluated asset
columns from the same source and calendar, not an independent future replication.
The 1,721 shared origins give 13,768 primary contract cases. The overall superiority
gate **fails**: mean primary-minus-score differences are +0.001956 versus fitted
arithmetic pooling, -0.013787 versus uniform arithmetic pooling, +0.005058 versus
development-selected experts and -0.004231 versus fitted transformed pooling.
All four comparisons, all 16 methods, both circular block lengths (20,60), 5,000
shared draws per length and excluded final one-step origins remain available.
These bootstrap limits are approximate historical diagnostics.

The independent verifier reconstructs rates/tails, forecast banks, 102,768 online
updates, static-fit objectives and dual witnesses, every metric, causal selection
checks and all stored bootstrap draws. Generic algebra and synthetic controller
checks supplement this replay. They do not provide directed-rounding certification
of floating-point financial forecasts. Previous sections' training runs are
preserved and were not rerun as part of this aggregation extension.

## Forgetting gradient history

Four distinct rules now share the same transformed pooling and maturity clock:
cumulative gradient energy, exponentially discounted energy, an exact finite norm
window, and periodic resetting of both weights and energy. Forgetting norm history
alone does not erase the dependence of current weights on past observations.
A valid nonmonotone-step regret bound retains positive variation of inverse step
sizes. The restart synchronization statement is conditional on an unchanged expert
bank and aligned reset clock.

The known-law study contains seven laws, 32 replications, two receipt latencies and
22 settings (19 screened settings plus three matched-step diagnostic controls).
At c=0.1, discount125 reduces changing-law conditional excess score from 0.48136 to
0.38686, but its old-market development score is slightly worse. Smaller step
multipliers improve that market criterion while failing the original controlled
response/stationary conditions. No setting passes the complete selection rule;
the operating candidate remains cumulative c=0.1. NZD/SGD/KRW/ZAR were not loaded
or evaluated. The transfer script records this nonexecution before any rate read.

Independent extended-precision replay reconstructs all 9,856 synthetic cases,
59,136 scalar metric values, 882 stored trace arrays, 176 old-market records and
370 paired intervals. These checks are not directed-rounding certificates.

To regenerate the complete study without overwriting frozen original evidence:

```bash
python reproduction/reproduce_forgetting.py
```

This creates a sibling `Gabriel_Forgetting_Replay` project with all required local
inputs and isolated generated outputs. It runs the three benchmark stages,
summary and two independent verifiers, then compares the main scalar results and
selection against the original. The wrapper itself is supplied; the individual
programs were executed and checked in this research run. Use the verification
commands above for a read/recompute audit of the included outputs.

The initial aligned-switch execution was superseded before its numerical outcomes
were examined. The retained v2 protocol uses nonmatching change times. The staged
search and this development amendment are recorded explicitly in the protocol
files. A trace archive was rebuilt from the same seeds and recurrence after a
technical serialization failure; `forgetting_archive_rebuild.json` records its
current container hash. Independent replay checks its values against the scalar
results. The frozen scientific selection records remain unchanged.

## Data attribution and rights

The unchanged UEA time-series files are distributed by the TSML Archive Maintainers
under Creative Commons Attribution 4.0 International. `data/ATTRIBUTION.md` gives
original collectors, source DOIs, license links, split details and preprocessing.
The recorded file checksums identify the exact inputs used. These notices apply
to the external datasets; they do not assign a license to the author's manuscript
or software. The license selected for the public deposit governs the original
materials within its stated scope. Python and LaTeX dependencies are not bundled
and retain their respective licenses.
