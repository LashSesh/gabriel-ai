TECHNISCHE PRÜFUNG · 26. SEPTEMBER 2026

QSO für Gabriel

Substanz, Grenzen und übertragbare Kerne

<b>Ergebnis:</b> Das Repository enthält verwertbare mathematische und technische Bausteine. Die stärkste direkte Ausbeute ist eine exakte Referenz für vollständige Graphen sowie eine Schnittstelle für gezielte Zustandsabfragen. Die vorhandene Routen- und Kalibrierungslogik muss vor einer Übernahme teilweise korrigiert oder ersetzt werden. Ein Geschwindigkeits- oder Qualitätsgewinn für Gabriel wurde in dieser Prüfung nicht gemessen.

Was die 5.040 Permutationen tatsächlich verbinden

S₇ ist die Gruppe aller Bijektionen einer Menge mit sieben Elementen; ihre Ordnung ist 7! = 5.040. Entscheidend ist die <b>Gruppenwirkung</b>: Welche Objekte werden umbenannt oder umgeordnet, und welche Ausgabe soll dabei erhalten bleiben? Die gleiche Anzahl liefert noch keine gemeinsame Engine-Semantik.

<b>Komponente</b> | <b>Sieben Objekte und Aufgabe</b>
Gabriels Graphsignatur | Knotenbezeichnungen; Wirkung auf die Adjazenzmatrix; kanonischer Vertreter einer Umbenennungsklasse.
QSO / MEF-Routenraum | Sieben Operatorplätze; Auswahl einer Ausführungsreihenfolge. Die Operatornamen sind zwischen Modulen nicht einheitlich.
QSO / MEF-Geometrie | Zentrum plus sechs Hexagonpositionen; Permutation dieser sieben Koordinaten bei sechs festgehaltenen weiteren Positionen.

Der implementierte Metatron-Graph

Der numerische QSO-Kern verbindet alle 13 Knoten durch 78 ungewichtete Kanten: Er ist genau der vollständige Graph K₁₃. Die hinterlegten Koordinaten und Knotentypen gehen nicht in seine Standard-Adjazenzmatrix ein. Daher hat dieser <i>unmarkierte Graph</i> die Automorphismengruppe S₁₃ mit 13! = 6.227.020.800 Elementen. Werden Typen oder geometrische Abstände zusätzlich erhalten, entsteht eine andere Symmetrieaufgabe. Beliebige lokale Potentiale können die Hamilton-Symmetrie weiter brechen.

Gabriel übernimmt für seine Signatur gerade keine geometrischen Gerüstkanten: Die Eingabeadjazenz wird eingebettet und aufgefüllt. Die gemeinsame Metatron-Terminologie bezeichnet somit eine nachvollziehbare Herkunft, aber keine nachgewiesene funktionale Gleichheit. [Q1, Q5, G1]


---

MATHEMATISCHER KERN

Ein brauchbares Ergebnis: exakte Zustandsentwicklung

Für einen vollständig verbundenen Graphen mit einheitlichem Kantengewicht w, einheitlichem Potential ε und der QSO-Konvention H = −Jw(nI − 11ᵀ) + εI definiere P = 11ᵀ/n. P projiziert auf den konstanten Vektor; I − P auf sein orthogonales Komplement. Beide Teilräume sind invariant.

U(t) = exp(−iεt) [P + exp(iJwnt)(I − P)].

Für einen Eingabezustand genügt deshalb eine Summe über seine Komponenten und eine komponentenweise Linearkombination: <b>O(n) Aufwand für eine Zustandsabfrage</b>. Die Ausgabe einer vollständigen Matrix benötigt bereits O(n²) Werte. Die Reduktion folgt aus zwei Eigenräumen und benötigt keine Aufzählung der n! Automorphismen. Für Gabriels positives Laplace-Vorzeichen ist das Vorzeichen der nichttrivialen Phase umzukehren.

Die neu ausgeführte Python-Referenz verglich die Formel auf K₁₃ für drei Kopplungen und fünf Zeiten mit SciPys Matrixexponential; größter absoluter Matrixeintragsfehler: 9,71 × 10⁻¹⁴. Die zusätzlich implementierte portable Zustandsaktion bestand 360 Vergleichsfälle für n = 1, 2, 3, 7, 13, 31, beide Vorzeichen und verschiedene Gewichte, Kopplungen und Zeiten; größter Vektorfehler: 8,81 × 10⁻¹⁴. Das sind numerische Referenzvergleiche, keine Rundungszertifikate oder Durchsatzbenchmarks.

Warum die angebotene Zentralität kein Signal enthält

Der Toolkit-Code summiert Übergangswahrscheinlichkeiten gleichgewichtet über sämtliche Basis-Startzustände. Für jede unitäre Matrix gilt:

Σⱼ |Uᵢⱼ(t)|² = (UU†)ᵢᵢ = 1.

Damit ist die Zentralität für jeden Knoten gleich, unabhängig vom Graphen. Die anschließende Anomalie aus zwei solchen Vektoren ist exakt null. Gegenproben mit K₁₃, Pfadgraph und leerem Graphen ergaben nur Rundungsstreuung bis 6,11 × 10⁻¹⁵. Mehr Knoten oder aufwendigere Geometrie beheben dieses Informationsproblem nicht. [Q2]

Die sinnvolle Schnittstelle

Erhalten bleiben muss die Bedingung auf eine Quelle: p(i,t | ψ₀), Rückkehrwahrscheinlichkeiten oder Antworten auf ein explizites Merkmalsfeld. QSO speichert dafür sinnvoll die Überlappungen mit der Eigenbasis. Gabriel teilt bereits Phasenberechnungen zwischen Abfragen; zusätzlicher Nutzen entstünde vor allem dann, wenn ein Verbraucher tatsächlich nur wenige Zustände statt aller Knotenpaare benötigt. Diese geänderte Ausgabe muss gegen die nachgelagerte Aufgabe geprüft werden.

Eine einzelne spektrale Probe muss beliebige verschiedene Graphen nicht unterscheiden. Weder die geschlossene Clique-Formel noch die Schnittstellenidee wird hier als neue mathematische Entdeckung beansprucht. Ihr Wert liegt in einer überprüfbaren, passend begrenzten Übernahme. [Q1, Q3, G2]


---

KORREKTHEIT DER DIAGNOSTIK

Drei Gegenbeispiele mit unmittelbarer Integrationsfolge

<b>1. Zeitmittel bei entarteten Eigenwerten.</b> Die implementierte Summe Σₐ |cₐ|² |vₐ(i)|² verwirft auch Kohärenzen innerhalb desselben Eigenraums. Allgemein richtig ist Σ<sub>E</sub> |(P<sub>E</sub>ψ₀)ᵢ|² über verschiedene Eigenwerte. Im QSO-Standardmodell auf K₁₃ (J = 1, w = 1, ε = 0) ist ein Eigenwert zwölffach entartet. Für einen Basis-Startzustand ist das wahre Rückkehrmittel 145/169 ≈ 0,858. Zwei zulässige Eigenbasen liefern mit der Quellformel dagegen etwa 0,296 und 0,163. Diese Werte zeigen die Basisabhängigkeit der Formel; sie sind keine behaupteten Ausgaben des Rust-Eigensolvers. [Q3]

<b>2. Krylov-Fehlermeldung.</b> Bei Unterraumdimension eins meldet die implementierte Residuenlogik null, weil der notwendige ausgehende Lanczos-Koeffizient fehlt. Für K₁₃ bei t = 0,1 beträgt der unabhängig berechnete Zustandsfehler etwa 0,328 und die Norm des Schrödinger-Defekts √12. Ein kleiner gemeldeter Wert ist hier kein gültiger Fehlernachweis. Auch ein richtig berechneter momentaner Defekt benötigt für eine Zustandsfehlergrenze eine kontrollierte zeitliche Integration. [Q4]

<b>3. Behaupteter 3,93-facher Treffervorteil.</b> Der Quellcode lässt beim endlichen Erwartungswert alle bis zum Horizont erfolglosen Verläufe weg. Bei 24 Schritten bleiben 74,25 % ohne Treffer; nur die erfolgreiche Teilmasse trägt zur Zahl 3,051 bei. 12/3,051 ergibt den beworbenen Faktor 3,93. Schon die zensierte mittlere Schrittzahl einschließlich aller bis Schritt 24 getragenen Kosten beträgt aber 20,872. Zusätzlich fehlt die Zustandsänderung durch wiederholte Quantenmessung: Der Code verwendet ungestörte Besetzungswahrscheinlichkeiten als künstliche Hazardraten. Das ist weder ein tragfähiger allgemeiner Quanten- noch ein CPU-Geschwindigkeitsnachweis. [Q4]

Gruppen- und Routenlogik

Beide geprüften S₇-Enumeratoren erzeugen genau 5.040 verschiedene Elemente, jedoch in unterschiedlicher Reihenfolge. Ein Routenindex ist deshalb nur zusammen mit einer festgelegten Enumerationskonvention eindeutig. Ein weiterer Selektor liefert wegen eines frühen Casts auf <i>usize</i> auf 32- und 64-Bit-Systemen unterschiedliche Indizes für dieselben Eingaben.

Im MetatronRouter ist die Summe der Werte einer gültigen 13-Permutation stets 91. Das Kriterium <i>sum % 4</i> wählt daher immer dieselbe Operatorfolge. Die zehn Standardkandidaten enthalten höchstens sechs unterschiedliche Kandidatenpermutationen. Die als Invarianzprojektion bezeichnete Mittelung ist weder invariant noch idempotent; exakte rationale Gegenbeispiele liegen bei. Der Resonanzwert ignoriert den übergebenen Zustand. [Q5]

Diese Befunde unterscheiden fehlerhafte Kriterien von korrekt aufgezählten Permutationen. Aus einem Defekt folgt kein pauschales Urteil über alle 21 Workspace-Komponenten.


---

INTEGRATION UND BESTEHENDER GABRIEL-STAND

Den D₆-Befund präzise abgrenzen

Ein QSO/MEF-Hilfsgenerator zählt sechs Rotationen und sechs Spiegelungsachsen durch Hexagonecken. Gegenüberliegende Ecken definieren jedoch dieselbe Achse: Es entstehen zwölf Einträge, aber nur neun verschiedene Permutationen; die Menge ist nicht abgeschlossen. Die korrekte Konstruktion {rᵏ} ∪ {rᵏs}, k = 0,…,5, wurde auf zwölf verschiedene Elemente und alle 144 Produkte geprüft.

<b>Derselbe Fehler existiert in Gabriels öffentlicher D₆-Hilfs-API.</b> Die Quellsuche findet dort nur Definition und eigenen Längentest; die gegenwärtigen dichten, gepackten und indizierten Signaturpfade rufen sie nicht auf. Dieser Fund widerlegt daher nicht die bisherige S₇-Kanonisierung oder deren gemessene Beschleunigung. Er sollte bei der nächsten Codepflege mit einem Eindeutigkeits- und Abschlusstest korrigiert werden. [G1, Q5]

QSO enthält außerdem einen korrekten, gesonderten D₆-Abschluss in <i>qso.rs</i>. Eine weitere Routine, die alle Graphautomorphismen aufzuzählen behauptet, liefert 48 Einträge, davon 36 verschieden und nicht abgeschlossen. Die gleich benannten Routinen dürfen nicht miteinander verwechselt werden. [Q1]

Welche Systemteile tragen?

<b>Teil</b> | <b>Bewertung für Gabriel</b>
Direkter TRITON-Suchkern | Verwertbare experimentelle Baseline: Startseed, begrenzte Vorschläge, echte Auswertungsfunktion, Bestwert und Budget. Kein Konvergenz- oder Überlegenheitsnachweis.
TRITON-Feedback-Wrapper | Konstanter Dummy-Evaluator; nachgereichte Resultate ändern nur Abbruchzähler, nicht das eigentliche Suchgedächtnis. So nicht übernehmen.
SCS und Telemetrie | Kalibrierung verbessert Metriken anhand festgelegter Zuschläge ohne neue Kandidatenmessung. Dashboard erzeugt Demonstrationswerte. Keine Evidenz für Selbstoptimierung.
Lokales / IBM-Backend | Lokale Ausführung ignoriert die Schaltung; reale IBM-Ausführung endet als nicht implementiert. 13 komplexe Amplituden sind kein allgemeiner 13-Qubit-Zustand mit 8.192 Amplituden.
Dionice-Brücke | Leeres Führungsfeld, außerdem ungeordnete HashMap-Ausgabe ohne stabile Eingabezuordnung. Für Gabriels deterministische Wiederholung ungeeignet.

Die Suchidee lässt sich von den mangelhaften Integrationspfaden trennen. Übernommen werden sollten höchstens kleine, versionierte Adapter. Gabriels bestehender Eigentümer von Zustand, Journal, Aufnahmeprüfung und atomaren Commits bleibt maßgebend. Eine Beobachtung muss an Konfiguration, Auswerter, Daten, Seed und Budget gebunden sein; hypothetische Scores dürfen keine gemessenen Verbesserungen ersetzen. [Q6, G3]


---

AUSGEFÜHRTE PRÜFUNGEN UND AUSSAGEGRENZEN

Was tatsächlich geprüft wurde

Das gelieferte Archiv <b>qso-main.zip</b> wurde entpackt und sein Bestand inventarisiert: 600 ZIP-Einträge, davon 467 reguläre Dateien. Die 467 extrahierten Quelldateien stimmen byteweise mit dem Upload überein. Untersucht wurden die für Gabriel relevanten Graph-, Symmetrie-, Walk-, Routen-, Such- und Integrationspfade. Das ist keine vollständige Zeilenprüfung des gesamten Repositorys.

<b>Endliche und numerische Gegenproben:</b> beide S₇-Enumeratoren; D₆-Eindeutigkeit und Abschluss; konstante Routerauswahl; rationale Projektionsgegenbeispiele; 32-/64-Bit-Auswahl; vollständige K₁₃-Adjazenz; Automorphismenliste; Zentralität auf drei Graphfamilien; entartete Zeitmittel; Krylov-Dimension eins; Trefferraten mit vier Horizonten; geschlossene Propagatorformel. Die Python-Modelle bilden relevante Quellformeln nach; ihre Ausführung ist ausdrücklich von einer Rust-API-Ausführung getrennt.

<b>Portable Wiederholung:</b> Die Prüfscripte akzeptieren Quellverzeichnisse als Parameter. Originalausgaben, Wiederholungsausgaben, Quellhashes, Zufallsseed und Parameter sind mitgeliefert. Der Gabriel-Ausschnitt umfasst elf unveränderte Signaturdateien plus drei Kontextdateien. Die ergänzte Clique-Referenz ist experimenteller Prüfcode; sie wurde nicht in Gabriels Produktionspfad eingebaut.

<b>Rust:</b> <i>cargo check --locked --offline -p metatron-qso-rs --lib</i> war erfolgreich (Rust 1.95.0). Der erste Offline-Testversuch scheiterte an fehlenden Abhängigkeiten. Ein anschließender Testbuild scheiterte beim Erzeugen eines Criterion-Abhängigkeitsarchivs an einem Memory-Map-Fehler. Der erneute Kern-Testlauf mit angepassten Buildoptionen war erfolgreich: test result: ok. 31 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.24s. Alle Versuche und die abweichenden Buildoptionen sind erhalten. Ein erfolgreicher vorhandener Test ersetzt die mathematischen Gegenbeispiele nicht.

Was sich daraus noch nicht ableiten lässt

Es wurde kein Vergleichsbenchmark zwischen QSO und Gabriel ausgeführt, kein Hardware-Quantenvorteil nachgewiesen und keine Lernqualität auf einer neuen Aufgabe gemessen. Die bisherigen Gabriel-Durchsatzfaktoren stammen aus anderen Experimenten; sie werden hier weder auf QSO übertragen noch neu bestätigt. Die Quellprüfung ist kein Sicherheitsaudit, keine vollständige Abhängigkeitsprüfung und kein Nachweis, dass alle Workspace-Crates bauen.

Primärquellenkontext: E. Farhi und S. Gutmann, <i>Quantum Computation and Decision Trees</i>, Physical Review A 58, 915 (1998), DOI 10.1103/PhysRevA.58.915; öffentliches Manuskript arXiv:quant-ph/9706062. Diese Arbeit begründet den CTQW-Kontext, nicht die Leistungsbehauptungen dieses Repositorys. Die hier entscheidenden Befunde folgen aus den unten bezeichneten Quellstellen und eigenen Gegenrechnungen.


---

VERWERTUNGSENTSCHEIDUNG UND QUELLNACHWEISE

Der stärkste nächste Entwicklungsschritt

<b>Priorität 1:</b> Die implementierte Clique-Referenz als unabhängigen mathematischen Testfall verwenden. Ein Produktions-Spezialpfad darf nur bei tatsächlich einheitlichen Gewichten und Potentialen aktiviert werden. Gleiche ungewichtete Graphsignaturen genügen dafür nicht. Algebraische Gleichheit garantiert keine bitweise Gleichheit mit dem bisherigen Eigensolver; Schwellwertentscheidungen brauchen eine ausdrückliche Toleranz- oder Rückfallregel.

<b>Priorität 2:</b> Einen quellbedingten spektralen Adapter für wenige Zustände untersuchen. Vergleich gegen den vorhandenen Gabriel-Pfad mit gleichem Ausgabeauftrag, Genauigkeitsziel und Warm-/Kaltstartstatus; getrennte Messung von Einrichtungs- und Abfragekosten. Erst ein Verbraucher, der die volle Paarmatrix nicht benötigt, rechtfertigt die veränderte Schnittstelle.

<b>Priorität 3:</b> S₇ als kleinen, vollständig kontrollierbaren Ablauf-Suchraum verwenden. Dazu sind Operatorbedeutung, Abhängigkeiten, zulässige Reihenfolgen und eine reale Zielfunktion festzulegen. 5.040 Möglichkeiten können für eine begrenzte Aufgabe als vollständige Referenz dienen. Direkten TRITON-Kern erst nach Randfallkorrekturen bei gleichem Auswertungsbudget gegen einfache Suche vergleichen. Das ist ein Forschungsentwurf, kein bereits integrierter Planer.

Fundstellen

Q = mitgeliefertes <i>qso-main</i>; G = Gabriel-Quellstand des aktuellen Arbeitsprojekts. Ausführliche Einzelbefunde und präzise Zeilenangaben stehen zusätzlich in den drei technischen Reviews im Prüfarchiv.

<b>Q1</b> metatron-qso-rs/src/graph/metatron.rs, insbesondere 204-357 und 376-522; src/hamiltonian.rs:31-74,161-175; src/qso.rs:25-101.

<b>Q2</b> metatron-qso-rs/src/quantum_walk_toolkit.rs:72-145 (Zentralität und Anomalie).

<b>Q3</b> metatron-qso-rs/src/quantum_walk/continuous.rs:29-110 (Zustandsaktion, Zeitmittel, Dephasierung).

<b>Q4</b> metatron-qso-rs/src/quantum_walk/krylov.rs:71-142; analysis.rs:169-172,218-248; docs/quantum_walk_mixing.md:175-187.

<b>Q5</b> external/dioniceos/infinity-ledger/: mef-core/src/symmetries.rs und geometry.rs; mef-topology/src/metatron_router.rs; mef-router/src/{s7,s7_space,route_selection}.rs.

<b>Q6</b> metatron_triton/src/{search,strategy,spiral}.rs; metatron_backend/src/backends/{local,ibm}.rs; scs/calibrator.py; metatron_telemetry/src/api/handlers.rs; metatron_dionice_bridge/src/lib.rs.

<b>G1</b> native_pse/crates/pse-metatron/src/{group,embed,scan,small_signature,indexed_signature,bitgraph}.rs; generate_d6 insbesondere group.rs:127-133.

<b>G2</b> native_pse/crates/pse-topology/src/lib.rs:486-579 (spektrale Paarabfragen und Phasenwiederverwendung).

<b>G3</b> gabriel_runtime/CONTRACT.md:7-23 und REPLAY.md:8-25 (Zustandsbesitz, Commit und Wiederholung).

Quellidentität SHA256 (qso-main.zip):<br/>0c20d1f9f936471a13eaa8aad52c8fd8295c7ecc9d959191ca7e97e9c74ce216
