# QSO S7 / Metatron contract review for Gabriel

Date: 2026-09-26. Scope: source review of the S7 enumerators, router, relevant geometry/group utilities and immediate routing callers in `external/dioniceos/infinity-ledger`, compared against Gabriel's delivered native `pse-metatron` source. This is not an audit of the complete QSO repository. No Rust build, QSO execution, performance benchmark or production edit was performed for this subreview. The finite source-model checks in `checks/s7_contracts.py` were executed; their outputs and source hashes are in `checks/s7_contracts.json`.

Paths below prefixed `Q/` mean `qso_review/source/qso-main/external/dioniceos/infinity-ledger/`; `G/` means `recovered/project/Gabriel/native_pse/crates/pse-metatron/src/`.

## Main result

There is a real shared algebraic object, S7, but different actions and computational contracts. QSO is useful as research raw material for a bounded route-planning / transformation experiment. It does not supply a demonstrated replacement for Gabriel's graph canonicalizer, and the inspected router has correctness defects that preclude direct incorporation as a superior engine. The comparison also detects an existing auxiliary D6 defect in Gabriel; current signature computation does not call that API.

## What the 5040 permutations mean

| Component | Seven objects | Action / output | Relation to Gabriel |
|---|---|---|---|
| `Q/mef-router/src/s7.rs:119–143`, `s7_space.rs:3–22`, `mef-schemas/src/route_spec.rs:5–43` | Seven named operator slots DK, SW, PI, WT, RES1, ADAPTER, RES2 | One order selected by a hash of seed / metrics; a RouteSpec is returned | A candidate schedule representation, not graph canonicalization |
| `Q/mef-core/src/symmetries.rs:30–36,79–92`; `mef-topology/src/metatron_router.rs:353–387` | Centre plus six hexagon coordinates, positions 1–7; positions 8–13 fixed | Permute a 13-vector, run state transformations, undo initial permutation | Shares Gabriel's active-position embedding, but transforms states and selects among heuristic routes |
| `G/group.rs:20–46`, `small_signature.rs:37–54`, `indexed_signature.rs:16–22` | Seven active vertex labels (shorter input padded with isolated vertices) | Act by adjacency conjugation, compute an orbit representative and stabilizer; index optionally replaces enumeration | Existing exact finite graph-signature task |

`7! = 5040` is the number of bijections of any seven-element set. It does not by itself encode a geometric object, a semantics, an optimization criterion or a speed advantage. The actions can be related only by an explicit map preserving the properties required by the caller.

The geometric qualification matters. QSO's positions are centre + planar hexagon + six selected cube corners (`Q/mef-core/src/geometry.rs:66–87`). Full edges are explicitly K13 (`geometry.rs:137–144`); as an unweighted graph K13 has all vertex permutations as automorphisms, not a uniquely distinguished S7. In the partial graph, centre↔hexagon exchange is not an automorphism: swapping 1 and 2 changes edges (1,4),(1,5),(1,6) into (2,4),(2,5),(2,6). It is also not a Euclidean symmetry of the centre+hexagon configuration. In Gabriel, `G/embed.rs:3–13` explicitly omits scaffold edges and zero-pads the input adjacency. Its S7 computation therefore does not depend on the drawn cube geometry.

## Findings requiring repair before reuse

### 1. The advertised D6 enumeration is not a group

`Q/mef-core/src/symmetries.rs:142–188` includes six rotations and reflections about the six centre-to-vertex axes. Opposite vertices define the same unoriented axis: axes 2 and 5 yield the same permutation, as do 3/6 and 4/7. The output has 12 entries but **9 distinct permutations**. It omits the three edge-midpoint reflections and is not closed under composition.

Exact counterexample (permutations are one-based):

- r = (1,3,4,5,6,7,2), a one-step hexagon rotation.
- s = (1,2,7,6,5,4,3), reflection about the axis through node 2.
- r∘s = (1,3,2,7,6,5,4), absent from the returned list.

A smallest sound construction is `{r^k : 0≤k<6} ∪ {r^k∘s : 0≤k<6}`. The standalone check constructs this set and verifies 12 distinct elements and closure for all 144 ordered products.

**Inherited Gabriel issue:** `G/group.rs:127–133` has the same construction; `group.rs:210–214` tests list length only. An exhaustive source-symbol search over native_pse Rust files finds `generate_d6` only at its definition and own test, and `hexagon_reflection` only at its definition and the D6 constructor. The current dense signature path imports `generate_s7` and `permutation_matrix_13` in `G/scan.rs:13,74–80`; the packed path uses `S7BitCache` (`small_signature.rs:10,18–20,37–54` and `bitgraph.rs:13`), and indexed signature reads the finite S7 tables (`indexed_signature.rs:12–22,52`). Thus no current complete-signature field depends on this D6 defect. It remains a defective exposed auxiliary API. This assessment covers present source callers, not unknown external callers.

### 2. The router does not vary operator order with its permutation

`Q/mef-topology/src/metatron_router.rs:699–730` computes `sum(permutation) % 4` to select one of four sequences. Every valid permutation of 1…13 has sum 91. All 5040 candidate permutations therefore select index 3 and the sequence **WT → PI → SW → DK**. The four-way selection is inert on the valid domain. The standalone finite check verifies this for all 5040 permutations. The unit test at lines 1160–1171 uses zero-based 0…12 even though the actual router uses one-based permutations, and only checks that four operators occur.

This does not make every vector transformation identical: conjugating a non-equivariant transformation can still change the result. It does invalidate the claim that this selector realizes permutation-dependent operator sequencing.

### 3. Ten candidate entries contain at most six distinct routes

`select_optimal_route` requests 10 candidates (`metatron_router.rs:264–265`). `select_candidate_permutations` starts with identity, adds the first three C6 entries and then the first three D6 entries (`641–665`). The D6 list starts with C6, including identity. These first seven entries are only three distinct permutations. Three subsequent sampled S7 indices are distinct from one another but are not deduplicated against earlier entries (`667–695`). Hence the ten returned entries contain **at most six** distinct permutations. Selection is heuristic subset search, not a search over all 5040 routes, and is not globally optimal.

### 4. The claimed path-invariance projection is neither invariant nor idempotent

`metatron_router.rs:528–565` averages identity plus the first three C6 rotations, whose first is again identity. On finite nonnegative inputs the following sorting and placement returns that average unchanged: sorted magnitudes are assigned back to the positions from which those same magnitudes came. Thus its operator is `P = (2I + R + R²)/4`, not a full group average.

For x = (0,1,0,0,0,0,0) on the seven active positions:

- P x = (0,1/2,0,0,0,1/4,1/4).
- P² x = (0,1/4,0,1/16,1/8,5/16,1/4), unequal to P x.
- P R x = (0,0,0,0,1/4,1/4,1/2), unequal to P x.

The remaining six coordinates can be zero. These are exact rational counterexamples, not floating-point tolerance artifacts. A full C6 average would be an invariant idempotent projection over real arithmetic, but would change the implemented transformation and discard orientation information. A graph canonical representative and an averaged state are also different outputs with different uses.

### 5. “Resonance” does not evaluate the candidate state

`metatron_router.rs:774–776` declares its argument `_state` and always calls `self.qlogic.step(0.0)`. `Q/mef-core/src/qlogic.rs:47–53,223–236` constructs a fixed sinusoidal pattern from the configured node count and that time. For a fixed QLogic configuration, all candidate states receive the same resonance score. Consequently the route score at `metatron_router.rs:768–770` is a constant resonance factor times average `1/(1+delta_norm)`, favoring smaller intermediate changes. It is not evidence of solving a task or improving a task-conditioned loss. `target_properties` is only included in cache-key generation and is never used by `evaluate_route`.

### 6. Determinism and route identity need explicit contracts

There are three incompatible route conventions:

- `Q/mef-router/src/route_selection.rs:19–36`: recursively generated zero-based permutation, hash only seed plus six-decimal mesh score, index uses `hash_value as usize`, ID `route_NNNN`.
- `Q/mef-router/src/s7.rs:73–143`: Heap-order one-based sigma plus named slots, sorted metric serialization, another hash construction and index; hash also cast to `usize` before selection.
- `Q/mef-topology/src/metatron_router.rs:291–298,399–405`: UUIDv4 route IDs and timestamps, incompatible with byte-identical output replay absent normalization/persistence.

The two enumerators each generate all 5040 permutations correctly in the executed source-model checks, but their enumeration order differs already at index 1. An index is meaningful only together with an enumeration-version contract.

Machine-word dependence is concrete in the exported selector: with seed `seed123` and metrics betti=2, lambda_gap=0.5, persistence=0.3, the modeled code gives index **4898 on 64-bit** and **4466 on 32-bit**, due to the `u64 as usize` cast before modulo (`route_selection.rs:30`). This calculation uses the exact SHA256 input and source truncation semantics, not a Rust execution. `s7.rs:113` additionally uses ordinary machine-word addition; overflow policy can change behavior for boundary hash values.

`generate_cache_key` serializes a HashMap directly (`metatron_router.rs:926–931`), so equivalent target properties inserted in different map iteration order need not yield the same key. That key omits public mutable router configuration. `seed` is recorded but is not included in its candidate-selection hash at 667–675. Public route structs lack validation before transformation; `permutation_matrix` assumes range/uniqueness (`symmetries.rs:79–92`). `mef-schemas/src/route_spec.rs:104–142` only checks length/range in its validator, not uniqueness and cross-field agreement; its stricter constructor is not a universal validation boundary.

### 7. Immediate callers establish selection, not full execution of seven named slots

The actual public adapter imports `route_selection::select_route` (`Q/mef-router/src/adapter.rs:3,29–44`), not the more detailed `s7::select_route_v2`. Service mode explicitly returns “not yet implemented”. `Q/mef-knowledge/src/pipeline.rs:59–68` returns the selected specification, and the HTTP extension at `mef-api/src/routes/extension.rs:131–144` returns it as JSON. In the immediate caller chain inspected, a route is produced; the seven named slots are not executed as a complete pipeline. This is a bounded caller finding, not a claim that no other module in the repository performs transformations.

Even the acronyms have different descriptions: schemas say DK=Deep Knowledge, SW=Swarm, WT=Witness (`mef-schemas/src/route_spec.rs:7–21`); the transformation router defines DK=DoubleKick, SW=Sweep, WT=WeightTransfer (`metatron_router.rs:23–42`). These types require an explicit semantic translation before integration.

## What can be reused productively

1. **Finite permutation space as an exhaustive test oracle.** A correctly implemented S7 action is small enough to test uniqueness, inverse/composition laws, equivariance/invariance and route constraints exhaustively. Gabriel already has the graph-specific action and finite index. Avoid importing a second unversioned permutation order.
2. **A bounded transformation planner as a distinct experimental module.** Give each operation an input/output type, preconditions, cost, state reads/writes and task-loss contract. Search only feasible orders (linear extensions of dependencies). Compare fixed baseline, exhaustive oracle for small instances and heuristic routing on held-out tasks. A hash selects reproducibly; it is not an objective optimizer.
3. **Explicit group actions.** Keep separate `VertexRelabeling`, `GeometricSymmetry` and `OperatorSchedule` types, even when their encodings all contain seven integers. Record the action and enumeration version in reproducible route identities.
4. **Repair auxiliary group correctness independently.** Correct D6 via one rotation and one reflection generator; add distinctness, closure, inverse and action-law tests. This repair can be validated without touching Gabriel's measured S7 canonicalizer.

No measured speed advantage or improved predictive/decision quality follows from these source findings. QSO's graph/action concepts can inform a separate planner experiment; Gabriel's current graph-signature engine is already the more direct implementation of the bounded canonicalization task.
