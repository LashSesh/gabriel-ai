# QSO quantum and graph core: read-only assessment for Gabriel

All source locations below are relative to `qso_review/source/qso-main/metatron-qso-rs/`, unless explicitly identified as Gabriel. This review inspected source and ran an independent Python reproduction of formulas. It did **not** compile or execute the supplied Rust implementation. The source and Gabriel were not modified. Reproduction: `checks/core_checks.py`, outputs `checks/core_checks.json` (Python, NumPy 2.3.5, SciPy 1.17.0, seed 20260926).

## Result

There is a usable small classical spectral-simulation core, together with enough problematic interpretation and diagnostics that wholesale assimilation would weaken Gabriel. The strongest immediate extraction is an exact complete-graph reference propagator and a source-conditioned spectral-probe interface, followed by a repaired Krylov implementation if measurements justify it. The supplied graph is not a new mechanism for enumerating Gabriel's S7 graph relabellings. Its default adjacency is exactly the complete graph K13, and its Hamiltonian reduces to a two-eigenvalue operator.

## Actual mathematical objects

* `src/graph/metatron.rs:376–415` assigns a center, six hexagon nodes, and six named cube nodes with coordinates. The "cube" collection contains six of the eight cube corners; it is not itself a full cube vertex set.
* `src/graph/metatron.rs:418–522` builds 78 distinct edges on 13 vertices. Independent reconstruction of those exact arrays confirms every unordered pair is included, hence A = 11ᵀ − I and L = 13I − 11ᵀ. `adjacency_matrix` lines 75–83 uses weight 1 on every edge. Coordinates do not enter the matrix, Hamiltonian, or CTQW.
* `src/quantum/state.rs:13–17,31–35` stores a fixed 13-component complex vector. This is one 13-level state, **not** a register of 13 qubits (whose unrestricted state vector has 8192 amplitudes). It is ordinary CPU-side linear algebra and sampling; no quantum-hardware execution occurs in these methods. Hardware hooks remain TODO in `src/qso.rs:240–241`.
* `src/hamiltonian.rs:31–74` builds H = −J L + diag(ε), with real symmetric dense eigendecomposition; the default is J = 1, ε = 0 (`src/params.rs:20–28`). `time_evolution_operator` lines 161–170 correctly forms Σ exp(−iEt)|v⟩⟨v| for a valid orthonormal eigensystem. The sign is opposite Gabriel's Laplacian generator; for real symmetric H, basis-to-basis transition probabilities are unaffected by reversing this sign, although general complex state amplitudes are not interchangeable.
* `src/quantum_walk/continuous.rs:29–36,45–68` caches overlaps c = V†ψ₀ and reconstructs V diag(exp(−iEt)) c. This is a sound repeated-state-evaluation method for fixed H; the full Hamiltonian state evolution (`hamiltonian.rs:173–175`) instead builds the entire propagator before applying it. The overlap path avoids that unnecessary work when only one initial state is queried.

## Symmetry distinctions

For the **uncolored graph actually implemented**, Aut(K13) = S13, of order 13! = 6,227,020,800. With center/hexagon/cube colors fixed, all within-class permutations remain graph automorphisms, giving S6 × S6, order 518,400. With coordinates and Euclidean distances additionally preserved, the symmetry is a different, much smaller object and must be computed using those constraints. None of these identifications supplies a canonical S7 action on this data.

There are two separate symmetry implementations:

1. `src/qso.rs:25–47,83–101` closes an actual rotation/reflection generator set acting on the six hexagon labels only. This is D6 of order 12, embedded as a **chosen subgroup** of S13. It is legitimate as a selected group, not as the full graph automorphism group. On-site potentials can break its Hamiltonian invariance; `verify_hamiltonian_symmetry` lines 226–232 performs an explicit check.
2. `src/graph/metatron.rs:204–274` claims to enumerate all automorphisms but only combines a short prescribed list. Reflections at lines 293–300 map i → 2a−i mod 6, so six loop iterations generate only three distinct reflections. The six rotations plus three unique reflections give nine unique hexagon permutations. The cube generator (lines 306–335) is explicitly four samples. Independent reproduction gives 48 returned entries, 36 unique permutations, and a concrete failed closure witness in the JSON. `automorphism_group_order` lines 354–357 therefore returns 48, which is neither a valid order of the returned distinct set nor the graph's group order. Do not use this routine to justify reductions or canonicalization.

Gabriel's 5040 = 7! concerns relabellings of seven vertices in its bounded graph-signature problem. A seven-label permutation space and a 13-node all-to-all graph may be linked by an explicitly defined representation or motif mapping, but the common vocabulary "Metatron" does not establish that map or reduce its cost.

## Decisive counterexamples and repairs

### 1. Centrality collapses identically; anomaly output lacks structural signal

`src/quantum_walk_toolkit.rs:72–113` accumulates probabilities from **all** basis initial states at the same times and with equal weight, then normalizes. For any unitary U(t),

    sum_j |U_ij(t)|² = [U(t)U(t)†]_ii = 1.

Therefore its raw centrality is 1/n for every vertex of every graph; the max-normalized output is identically 1. `quantum_walk_anomaly_score` lines 131–145 subtracts two such vectors, so it is identically zero in exact arithmetic. This is not specific to the complete graph and cannot be repaired by a more complicated geometry. Python mirrors on K13, P13 and the empty graph gave maximum score spreads 6.11e−15, 8.88e−16 and 0, respectively. These are roundoff, not discrimination.

A useful replacement must retain conditioning: p(i,t | ψ₀), a nonuniform source distribution, return probabilities p(i,t | i), pairwise transfer, or response to an explicitly weighted feature source. A single nonuniform probe must also have a documented label action. Do not claim discrimination before testing nonisomorphic and cospectral counterexamples; arbitrary graphs need not be separated by one spectral feature.

### 2. The quoted 3.93× hitting advantage is not an expected hitting-time comparison

`src/quantum_walk/analysis.rs:218–248` uses p(target,t_k) from the unconditioned trajectory as a hazard, forms first_prob = survival × p, and sums k × first_prob only to a finite horizon N. This is a constructed independent-hazard model. Repeated quantum detection normally updates the surviving state by the no-detection projector; that backaction is absent here. The code then divides the full classical mean by the incomplete first moment (`analysis.rs:169–172`).

For the exact default K13 propagator, J=1, dt=0.25, N=24, independent calculation reproduces:

* success probability 0.257487490446;
* incomplete first moment 3.051474908384;
* reported ratio 12 / 3.051474908384 = 3.932524552973.

But 74.25% of trajectories have not hit at the horizon and their costs are dropped. Even for this synthetic hazard model, E[min(T,24)] = 3.05147 + 24 × 0.74251 = 20.871775137680, already greater than the classical expectation 12. If survivors hit no earlier than step 25, the mean is at least 21.614287647234. Decreasing N to one creates a nominal 508.49× ratio solely by truncating failures. This is a decisive accounting counterexample, not a hardware-performance result. These advertised factors (`docs/quantum_walk_mixing.md:175–187` and nearby summary) must not be imported as Gabriel speedups.

### 3. Infinite-time average fails in degenerate eigenspaces

`src/quantum_walk/continuous.rs:90–110` evaluates Σ_a |c_a|² |v_a(i)|². This equals the Cesàro mean when the contributing eigenvalues are distinct. In general the correct expression is

    average p_i = Σ_E |(P_E ψ₀)_i|²,

where P_E projects onto the whole eigenspace of a **distinct** eigenvalue. Coherences inside a degenerate eigenspace do not oscillate away. The default K13 has eigenvalues 0 once and −13 twelve times, so this distinction is essential in the actual default, not an unusual edge case.

For ψ₀ = e₀, the true return average is 145/169 = 0.857988165680 and each other node has probability 2/169. Two valid orthonormal eigenbases related only by rotating the degenerate complement produce source-formula return values 0.295633750215 and 0.163217354937. Maximum distribution difference under that basis rotation is 0.194954173866. Independent eigensolvers need not return these particular bases; this demonstrates the formula's mathematical ambiguity, not the exact Rust-produced value.

`probabilities_at` lines 70–86 interpolates towards this basis-dependent distribution. That mixture can be given a dephasing interpretation in a specified rank-one eigenbasis, but it is not automatically the claimed Hamiltonian Cesàro mean or vertex-local noise model. `evolve` lines 39–42 and `state_at` remain unitary even when dephasing is configured. A coherent API must state whether it returns a pure state, density matrix, or phenomenological probability mixture. Rates and time domains also require validation.

### 4. Krylov residual uses the wrong beta and can certify a visibly bad result

`src/quantum_walk/krylov.rs:71–95` breaks at the target dimension before recording the next/outgoing Lanczos beta. `evolve` lines 137–142 instead takes the last **internal** beta, and uses zero if none was stored. For m = 1 this reports zero residual regardless of whether the initial state is an eigenstate.

At the default K13, ψ₀=e₀, t=0.1, the m=1 state is exp(i12t)e₀. Independent calculation gives vector error 0.327600193056 and Schrödinger defect norm √12 = 3.464101615138, while the reported residual is zero. Even a correctly computed instantaneous defect is not automatically an integrated state-error bound; use the Duhamel integral with Hermitian evolution and a controlled defect quadrature. Add dimension validation and reorthogonalization/breakdown handling if promoted. No reorthogonalization is present now. The current unit test (`krylov.rs:157–168`) checks only one favorable full-support K13 case at dimension 6.

### 5. Additional boundary issues relevant before reuse

* `QuantumOperator::from_permutation` (`src/quantum/operator.rs:41–62`) checks length/range but not uniqueness, so `[0;13]` is accepted despite being nonunitary. Validate bijectivity before using an input as a symmetry.
* `MetatronHamiltonian::from_matrix` (`hamiltonian.rs:76–109`) invokes a symmetric solver without enforcing finite symmetric input. Reject invalid matrices or require a typed symmetric constructor.
* `normalize_vector` (`quantum/state.rs:195–204`) changes a zero vector into e₀; this is an explicit fallback but can silently manufacture a state if a failed numerical calculation is treated as zero. Other nonfinite inputs are not rejected.
* Toolkit `samples` is unused; unvalidated dt/t_max can produce empty or nonsensical work. Its `mixing_time` is first entrance in a coarse absolute tolerance, not a proof of persistent mixing, and its `hitting_probabilities` are simply final occupation probabilities (`quantum_walk_toolkit.rs:179–219`).

## What to extract for Gabriel

### Priority A: independent analytic complete-graph oracle and optional specialization

For a uniformly weighted complete graph with weight w, uniform onsite ε and H = −Jw(nI−11ᵀ)+εI, put P = 11ᵀ/n. Then

    U(t) = exp(−iεt) [P + exp(iJwn t)(I−P)].

For Gabriel's +L convention reverse the nontrivial phase sign. The basis transfer probabilities are identical:

    p(i→j,t) = 4 sin²(Jwn t/2)/n²,                  i ≠ j,
    p(i→i,t) = 1 − 4(n−1) sin²(Jwn t/2)/n².

This yields O(n) action on a vector by computing its sum once; full matrix output costs O(n²). It gives an exact nontrivial reference for unitarity, degeneracy, threshold nonreachability and recurrence. Independent comparison with SciPy expm on n=13, J∈{0.25,1,1.7}, t∈{0,0.1,0.25,1,10} had maximum entry difference 9.71e−14.

The uniform-state/orthogonal-complement split is the substantive symmetry reduction; its size does not depend on enumerating any of the n! graph automorphisms. With a source basis state the whole trajectory lies in span{e_source,1}, a two-dimensional invariant subspace.

This specialization is valid only for an exactly recognized uniformly weighted clique and uniform potentials. QSO coordinate metadata do not justify it for a general weighted Gabriel graph. Matching graph presence signatures alone is insufficient because Gabriel's Laplacian uses weights. Algebraic equivalence does not imply bitwise identity to the current eigensolver, and threshold decisions near a boundary need an error policy. Do not silently substitute it into a reference-preserving benchmark mode.

### Priority B: retain conditioning and expose state-action queries

Gabriel currently computes all ordered-pair transfer probabilities and threshold scans from its spectral decomposition (`native_pse/crates/pse-topology/src/lib.rs:486–579`); its hoisted implementation already shares time/eigenmode phases. QSO supplies a natural alternative **interface**, not an immediate faster drop-in: evolve only a requested source or feature vector, caching its eigenbasis overlaps. Complexity becomes O(nk) per requested state/time rather than computing n sources, when the consumer truly does not need the whole pair matrix. This changes the output contract and must be evaluated as a separate mode with downstream utility tests. QSO's equal-source averaging destroys this potential signal and should be discarded.

### Priority C: corrected Krylov as a scalable optional approximation

For large sparse H and a few sources, Krylov exponential action could avoid full decomposition. The useful design is a certified/adaptive state-action backend with proper outgoing residual and integration of that residual, not the supplied faulty scalar. This is a research/implementation target; no speedup or certified error improvement has been demonstrated by this review. For fixed dimension 13, generic Krylov overhead may outweigh savings; benchmark before adopting.

## Claim boundaries

This archive implements classical simulations of quantum-model formulas and graph/oscillator heuristics. It does not by itself demonstrate quantum computational advantage, a superior learning architecture, or an S7/Metatron equivalence. Its standard linear algebra and clear fixed-size core are reusable; several diagnostic claims and numerical guards must be repaired or excluded. The exact clique oracle is immediately useful to Gabriel's verification suite; production acceleration and task-quality gains remain separate measurements.
