#!/usr/bin/env python3
"""Build the unified German assessment from the executed audit records."""
from pathlib import Path
import json
from xml.sax.saxutils import escape
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

HERE = Path(__file__).resolve().parent
OUT = HERE/'Gabriel_QSO_Pruefbericht.pdf'
for name, filename in [('Review','DejaVuSans.ttf'),('ReviewBold','DejaVuSans-Bold.ttf')]:
    pdfmetrics.registerFont(TTFont(name, str(HERE/'report_assets'/filename)))
pdfmetrics.registerFontFamily('Review', normal='Review', bold='ReviewBold', italic='Review', boldItalic='ReviewBold')
ink=colors.HexColor('#15283b'); accent=colors.HexColor('#087e8b'); muted=colors.HexColor('#526373')
styles={
 'title':ParagraphStyle('title',fontName='ReviewBold',fontSize=25,leading=31,textColor=ink,spaceAfter=17),
 'h':ParagraphStyle('h',fontName='ReviewBold',fontSize=14,leading=19,textColor=ink,spaceBefore=13,spaceAfter=9),
 'p':ParagraphStyle('p',fontName='Review',fontSize=10.0,leading=15.0,textColor=ink,spaceAfter=9),
 'small':ParagraphStyle('small',fontName='Review',fontSize=8.3,leading=12.0,textColor=muted,spaceAfter=7),
 'math':ParagraphStyle('math',fontName='Review',fontSize=10.6,leading=16,textColor=accent,leftIndent=12,spaceBefore=5,spaceAfter=11),
 'cell':ParagraphStyle('cell',fontName='Review',fontSize=8.5,leading=12.1,textColor=ink),
 'label':ParagraphStyle('label',fontName='ReviewBold',fontSize=9,leading=13,textColor=accent,spaceAfter=12),
}
story=[]; md=[]
def p(text,kind='p'):
    story.append(Paragraph(text,styles[kind])); md.append(text+'\n')
def h(text): p(text,'h')
def new(): story.append(PageBreak()); md.append('\n---\n')
def table(rows,widths):
    data=[[Paragraph(c,styles['cell']) for c in row] for row in rows]
    t=Table(data,colWidths=widths,hAlign='LEFT'); t.setStyle(TableStyle([
       ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e6eff2')),
       ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),8),
       ('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),7),
       ('BOTTOMPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,0),(-1,-1),.35,colors.HexColor('#d4dfe4'))]))
    story.extend([t,Spacer(1,12)]);md.append('\n'.join(' | '.join(row) for row in rows)+'\n')

p('TECHNISCHE PRÜFUNG · 26. SEPTEMBER 2026','label')
p('QSO für Gabriel','title')
p('Substanz, Grenzen und übertragbare Kerne','h')
p('<b>Ergebnis:</b> Das Repository enthält verwertbare mathematische und technische Bausteine. Die stärkste direkte Ausbeute ist eine exakte Referenz für vollständige Graphen sowie eine Schnittstelle für gezielte Zustandsabfragen. Die vorhandene Routen- und Kalibrierungslogik muss vor einer Übernahme teilweise korrigiert oder ersetzt werden. Ein Geschwindigkeits- oder Qualitätsgewinn für Gabriel wurde in dieser Prüfung nicht gemessen.')
h('Was die 5.040 Permutationen tatsächlich verbinden')
p('S₇ ist die Gruppe aller Bijektionen einer Menge mit sieben Elementen; ihre Ordnung ist 7! = 5.040. Entscheidend ist die <b>Gruppenwirkung</b>: Welche Objekte werden umbenannt oder umgeordnet, und welche Ausgabe soll dabei erhalten bleiben? Die gleiche Anzahl liefert noch keine gemeinsame Engine-Semantik.')
table([
 ['<b>Komponente</b>','<b>Sieben Objekte und Aufgabe</b>'],
 ['Gabriels Graphsignatur','Knotenbezeichnungen; Wirkung auf die Adjazenzmatrix; kanonischer Vertreter einer Umbenennungsklasse.'],
 ['QSO / MEF-Routenraum','Sieben Operatorplätze; Auswahl einer Ausführungsreihenfolge. Die Operatornamen sind zwischen Modulen nicht einheitlich.'],
 ['QSO / MEF-Geometrie','Zentrum plus sechs Hexagonpositionen; Permutation dieser sieben Koordinaten bei sechs festgehaltenen weiteren Positionen.'],
 ],[133,366])
h('Der implementierte Metatron-Graph')
p('Der numerische QSO-Kern verbindet alle 13 Knoten durch 78 ungewichtete Kanten: Er ist genau der vollständige Graph K₁₃. Die hinterlegten Koordinaten und Knotentypen gehen nicht in seine Standard-Adjazenzmatrix ein. Daher hat dieser <i>unmarkierte Graph</i> die Automorphismengruppe S₁₃ mit 13! = 6.227.020.800 Elementen. Werden Typen oder geometrische Abstände zusätzlich erhalten, entsteht eine andere Symmetrieaufgabe. Beliebige lokale Potentiale können die Hamilton-Symmetrie weiter brechen.')
p('Gabriel übernimmt für seine Signatur gerade keine geometrischen Gerüstkanten: Die Eingabeadjazenz wird eingebettet und aufgefüllt. Die gemeinsame Metatron-Terminologie bezeichnet somit eine nachvollziehbare Herkunft, aber keine nachgewiesene funktionale Gleichheit. [Q1, Q5, G1]','small')

new();p('MATHEMATISCHER KERN','label');h('Ein brauchbares Ergebnis: exakte Zustandsentwicklung')
p('Für einen vollständig verbundenen Graphen mit einheitlichem Kantengewicht w, einheitlichem Potential ε und der QSO-Konvention H = −Jw(nI − 11ᵀ) + εI definiere P = 11ᵀ/n. P projiziert auf den konstanten Vektor; I − P auf sein orthogonales Komplement. Beide Teilräume sind invariant.')
p('U(t) = exp(−iεt) [P + exp(iJwnt)(I − P)].','math')
p('Für einen Eingabezustand genügt deshalb eine Summe über seine Komponenten und eine komponentenweise Linearkombination: <b>O(n) Aufwand für eine Zustandsabfrage</b>. Die Ausgabe einer vollständigen Matrix benötigt bereits O(n²) Werte. Die Reduktion folgt aus zwei Eigenräumen und benötigt keine Aufzählung der n! Automorphismen. Für Gabriels positives Laplace-Vorzeichen ist das Vorzeichen der nichttrivialen Phase umzukehren.')
p('Die neu ausgeführte Python-Referenz verglich die Formel auf K₁₃ für drei Kopplungen und fünf Zeiten mit SciPys Matrixexponential; größter absoluter Matrixeintragsfehler: 9,71 × 10⁻¹⁴. Die zusätzlich implementierte portable Zustandsaktion bestand 360 Vergleichsfälle für n = 1, 2, 3, 7, 13, 31, beide Vorzeichen und verschiedene Gewichte, Kopplungen und Zeiten; größter Vektorfehler: 8,81 × 10⁻¹⁴. Das sind numerische Referenzvergleiche, keine Rundungszertifikate oder Durchsatzbenchmarks.')
h('Warum die angebotene Zentralität kein Signal enthält')
p('Der Toolkit-Code summiert Übergangswahrscheinlichkeiten gleichgewichtet über sämtliche Basis-Startzustände. Für jede unitäre Matrix gilt:')
p('Σⱼ |Uᵢⱼ(t)|² = (UU†)ᵢᵢ = 1.','math')
p('Damit ist die Zentralität für jeden Knoten gleich, unabhängig vom Graphen. Die anschließende Anomalie aus zwei solchen Vektoren ist exakt null. Gegenproben mit K₁₃, Pfadgraph und leerem Graphen ergaben nur Rundungsstreuung bis 6,11 × 10⁻¹⁵. Mehr Knoten oder aufwendigere Geometrie beheben dieses Informationsproblem nicht. [Q2]')
h('Die sinnvolle Schnittstelle')
p('Erhalten bleiben muss die Bedingung auf eine Quelle: p(i,t | ψ₀), Rückkehrwahrscheinlichkeiten oder Antworten auf ein explizites Merkmalsfeld. QSO speichert dafür sinnvoll die Überlappungen mit der Eigenbasis. Gabriel teilt bereits Phasenberechnungen zwischen Abfragen; zusätzlicher Nutzen entstünde vor allem dann, wenn ein Verbraucher tatsächlich nur wenige Zustände statt aller Knotenpaare benötigt. Diese geänderte Ausgabe muss gegen die nachgelagerte Aufgabe geprüft werden.')
p('Eine einzelne spektrale Probe muss beliebige verschiedene Graphen nicht unterscheiden. Weder die geschlossene Clique-Formel noch die Schnittstellenidee wird hier als neue mathematische Entdeckung beansprucht. Ihr Wert liegt in einer überprüfbaren, passend begrenzten Übernahme. [Q1, Q3, G2]','small')

new();p('KORREKTHEIT DER DIAGNOSTIK','label');h('Drei Gegenbeispiele mit unmittelbarer Integrationsfolge')
p('<b>1. Zeitmittel bei entarteten Eigenwerten.</b> Die implementierte Summe Σₐ |cₐ|² |vₐ(i)|² verwirft auch Kohärenzen innerhalb desselben Eigenraums. Allgemein richtig ist Σ<sub>E</sub> |(P<sub>E</sub>ψ₀)ᵢ|² über verschiedene Eigenwerte. Im QSO-Standardmodell auf K₁₃ (J = 1, w = 1, ε = 0) ist ein Eigenwert zwölffach entartet. Für einen Basis-Startzustand ist das wahre Rückkehrmittel 145/169 ≈ 0,858. Zwei zulässige Eigenbasen liefern mit der Quellformel dagegen etwa 0,296 und 0,163. Diese Werte zeigen die Basisabhängigkeit der Formel; sie sind keine behaupteten Ausgaben des Rust-Eigensolvers. [Q3]')
p('<b>2. Krylov-Fehlermeldung.</b> Bei Unterraumdimension eins meldet die implementierte Residuenlogik null, weil der notwendige ausgehende Lanczos-Koeffizient fehlt. Für K₁₃ bei t = 0,1 beträgt der unabhängig berechnete Zustandsfehler etwa 0,328 und die Norm des Schrödinger-Defekts √12. Ein kleiner gemeldeter Wert ist hier kein gültiger Fehlernachweis. Auch ein richtig berechneter momentaner Defekt benötigt für eine Zustandsfehlergrenze eine kontrollierte zeitliche Integration. [Q4]')
p('<b>3. Behaupteter 3,93-facher Treffervorteil.</b> Der Quellcode lässt beim endlichen Erwartungswert alle bis zum Horizont erfolglosen Verläufe weg. Bei 24 Schritten bleiben 74,25 % ohne Treffer; nur die erfolgreiche Teilmasse trägt zur Zahl 3,051 bei. 12/3,051 ergibt den beworbenen Faktor 3,93. Schon die zensierte mittlere Schrittzahl einschließlich aller bis Schritt 24 getragenen Kosten beträgt aber 20,872. Zusätzlich fehlt die Zustandsänderung durch wiederholte Quantenmessung: Der Code verwendet ungestörte Besetzungswahrscheinlichkeiten als künstliche Hazardraten. Das ist weder ein tragfähiger allgemeiner Quanten- noch ein CPU-Geschwindigkeitsnachweis. [Q4]')
h('Gruppen- und Routenlogik')
p('Beide geprüften S₇-Enumeratoren erzeugen genau 5.040 verschiedene Elemente, jedoch in unterschiedlicher Reihenfolge. Ein Routenindex ist deshalb nur zusammen mit einer festgelegten Enumerationskonvention eindeutig. Ein weiterer Selektor liefert wegen eines frühen Casts auf <i>usize</i> auf 32- und 64-Bit-Systemen unterschiedliche Indizes für dieselben Eingaben.')
p('Im MetatronRouter ist die Summe der Werte einer gültigen 13-Permutation stets 91. Das Kriterium <i>sum % 4</i> wählt daher immer dieselbe Operatorfolge. Die zehn Standardkandidaten enthalten höchstens sechs unterschiedliche Kandidatenpermutationen. Die als Invarianzprojektion bezeichnete Mittelung ist weder invariant noch idempotent; exakte rationale Gegenbeispiele liegen bei. Der Resonanzwert ignoriert den übergebenen Zustand. [Q5]')
p('Diese Befunde unterscheiden fehlerhafte Kriterien von korrekt aufgezählten Permutationen. Aus einem Defekt folgt kein pauschales Urteil über alle 21 Workspace-Komponenten.','small')

new();p('INTEGRATION UND BESTEHENDER GABRIEL-STAND','label');h('Den D₆-Befund präzise abgrenzen')
p('Ein QSO/MEF-Hilfsgenerator zählt sechs Rotationen und sechs Spiegelungsachsen durch Hexagonecken. Gegenüberliegende Ecken definieren jedoch dieselbe Achse: Es entstehen zwölf Einträge, aber nur neun verschiedene Permutationen; die Menge ist nicht abgeschlossen. Die korrekte Konstruktion {rᵏ} ∪ {rᵏs}, k = 0,…,5, wurde auf zwölf verschiedene Elemente und alle 144 Produkte geprüft.')
p('<b>Derselbe Fehler existiert in Gabriels öffentlicher D₆-Hilfs-API.</b> Die Quellsuche findet dort nur Definition und eigenen Längentest; die gegenwärtigen dichten, gepackten und indizierten Signaturpfade rufen sie nicht auf. Dieser Fund widerlegt daher nicht die bisherige S₇-Kanonisierung oder deren gemessene Beschleunigung. Er sollte bei der nächsten Codepflege mit einem Eindeutigkeits- und Abschlusstest korrigiert werden. [G1, Q5]')
p('QSO enthält außerdem einen korrekten, gesonderten D₆-Abschluss in <i>qso.rs</i>. Eine weitere Routine, die alle Graphautomorphismen aufzuzählen behauptet, liefert 48 Einträge, davon 36 verschieden und nicht abgeschlossen. Die gleich benannten Routinen dürfen nicht miteinander verwechselt werden. [Q1]')
h('Welche Systemteile tragen?')
table([
 ['<b>Teil</b>','<b>Bewertung für Gabriel</b>'],
 ['Direkter TRITON-Suchkern','Verwertbare experimentelle Baseline: Startseed, begrenzte Vorschläge, echte Auswertungsfunktion, Bestwert und Budget. Kein Konvergenz- oder Überlegenheitsnachweis.'],
 ['TRITON-Feedback-Wrapper','Konstanter Dummy-Evaluator; nachgereichte Resultate ändern nur Abbruchzähler, nicht das eigentliche Suchgedächtnis. So nicht übernehmen.'],
 ['SCS und Telemetrie','Kalibrierung verbessert Metriken anhand festgelegter Zuschläge ohne neue Kandidatenmessung. Dashboard erzeugt Demonstrationswerte. Keine Evidenz für Selbstoptimierung.'],
 ['Lokales / IBM-Backend','Lokale Ausführung ignoriert die Schaltung; reale IBM-Ausführung endet als nicht implementiert. 13 komplexe Amplituden sind kein allgemeiner 13-Qubit-Zustand mit 8.192 Amplituden.'],
 ['Dionice-Brücke','Leeres Führungsfeld, außerdem ungeordnete HashMap-Ausgabe ohne stabile Eingabezuordnung. Für Gabriels deterministische Wiederholung ungeeignet.'],
 ],[132,367])
p('Die Suchidee lässt sich von den mangelhaften Integrationspfaden trennen. Übernommen werden sollten höchstens kleine, versionierte Adapter. Gabriels bestehender Eigentümer von Zustand, Journal, Aufnahmeprüfung und atomaren Commits bleibt maßgebend. Eine Beobachtung muss an Konfiguration, Auswerter, Daten, Seed und Budget gebunden sein; hypothetische Scores dürfen keine gemessenen Verbesserungen ersetzen. [Q6, G3]','small')

new();p('AUSGEFÜHRTE PRÜFUNGEN UND AUSSAGEGRENZEN','label');h('Was tatsächlich geprüft wurde')
integrity=json.loads((HERE/'checks/source_integrity.json').read_text())
p('Das gelieferte Archiv <b>qso-main.zip</b> wurde entpackt und sein Bestand inventarisiert: 600 ZIP-Einträge, davon 467 reguläre Dateien. Die 467 extrahierten Quelldateien stimmen byteweise mit dem Upload überein. Untersucht wurden die für Gabriel relevanten Graph-, Symmetrie-, Walk-, Routen-, Such- und Integrationspfade. Das ist keine vollständige Zeilenprüfung des gesamten Repositorys.')
p('<b>Endliche und numerische Gegenproben:</b> beide S₇-Enumeratoren; D₆-Eindeutigkeit und Abschluss; konstante Routerauswahl; rationale Projektionsgegenbeispiele; 32-/64-Bit-Auswahl; vollständige K₁₃-Adjazenz; Automorphismenliste; Zentralität auf drei Graphfamilien; entartete Zeitmittel; Krylov-Dimension eins; Trefferraten mit vier Horizonten; geschlossene Propagatorformel. Die Python-Modelle bilden relevante Quellformeln nach; ihre Ausführung ist ausdrücklich von einer Rust-API-Ausführung getrennt.')
p('<b>Portable Wiederholung:</b> Die Prüfscripte akzeptieren Quellverzeichnisse als Parameter. Originalausgaben, Wiederholungsausgaben, Quellhashes, Zufallsseed und Parameter sind mitgeliefert. Der Gabriel-Ausschnitt umfasst elf unveränderte Signaturdateien plus drei Kontextdateien. Die ergänzte Clique-Referenz ist experimenteller Prüfcode; sie wurde nicht in Gabriels Produktionspfad eingebaut.')
status_path=HERE/'checks/workspace_core_test_adjusted.json'
if status_path.exists():
    result=json.loads(status_path.read_text())
    out=(HERE/'checks/workspace_core_test_adjusted.stdout').read_text()
    import re
    summary=re.findall(r'test result:.*',out)
    if result['returncode']==0:
        rust='Der erneute Kern-Testlauf mit angepassten Buildoptionen war erfolgreich: '+escape('; '.join(summary))+'.'
    else:
        rust='Der erneute Kern-Testlauf mit angepassten Buildoptionen endete mit Status '+escape(str(result['returncode']))+'. Die Rohprotokolle dokumentieren den genauen Befund; daraus wird keine erfolgreiche Testsuite abgeleitet.'
else:
    raise RuntimeError('Final Rust result missing: do not publish an incomplete validation report')
p('<b>Rust:</b> <i>cargo check --locked --offline -p metatron-qso-rs --lib</i> war erfolgreich (Rust 1.95.0). Der erste Offline-Testversuch scheiterte an fehlenden Abhängigkeiten. Ein anschließender Testbuild scheiterte beim Erzeugen eines Criterion-Abhängigkeitsarchivs an einem Memory-Map-Fehler. '+rust+' Alle Versuche und die abweichenden Buildoptionen sind erhalten. Ein erfolgreicher vorhandener Test ersetzt die mathematischen Gegenbeispiele nicht.')
h('Was sich daraus noch nicht ableiten lässt')
p('Es wurde kein Vergleichsbenchmark zwischen QSO und Gabriel ausgeführt, kein Hardware-Quantenvorteil nachgewiesen und keine Lernqualität auf einer neuen Aufgabe gemessen. Die bisherigen Gabriel-Durchsatzfaktoren stammen aus anderen Experimenten; sie werden hier weder auf QSO übertragen noch neu bestätigt. Die Quellprüfung ist kein Sicherheitsaudit, keine vollständige Abhängigkeitsprüfung und kein Nachweis, dass alle Workspace-Crates bauen.')
p('Primärquellenkontext: E. Farhi und S. Gutmann, <i>Quantum Computation and Decision Trees</i>, Physical Review A 58, 915 (1998), DOI 10.1103/PhysRevA.58.915; öffentliches Manuskript arXiv:quant-ph/9706062. Diese Arbeit begründet den CTQW-Kontext, nicht die Leistungsbehauptungen dieses Repositorys. Die hier entscheidenden Befunde folgen aus den unten bezeichneten Quellstellen und eigenen Gegenrechnungen.','small')

new();p('VERWERTUNGSENTSCHEIDUNG UND QUELLNACHWEISE','label');h('Der stärkste nächste Entwicklungsschritt')
p('<b>Priorität 1:</b> Die implementierte Clique-Referenz als unabhängigen mathematischen Testfall verwenden. Ein Produktions-Spezialpfad darf nur bei tatsächlich einheitlichen Gewichten und Potentialen aktiviert werden. Gleiche ungewichtete Graphsignaturen genügen dafür nicht. Algebraische Gleichheit garantiert keine bitweise Gleichheit mit dem bisherigen Eigensolver; Schwellwertentscheidungen brauchen eine ausdrückliche Toleranz- oder Rückfallregel.')
p('<b>Priorität 2:</b> Einen quellbedingten spektralen Adapter für wenige Zustände untersuchen. Vergleich gegen den vorhandenen Gabriel-Pfad mit gleichem Ausgabeauftrag, Genauigkeitsziel und Warm-/Kaltstartstatus; getrennte Messung von Einrichtungs- und Abfragekosten. Erst ein Verbraucher, der die volle Paarmatrix nicht benötigt, rechtfertigt die veränderte Schnittstelle.')
p('<b>Priorität 3:</b> S₇ als kleinen, vollständig kontrollierbaren Ablauf-Suchraum verwenden. Dazu sind Operatorbedeutung, Abhängigkeiten, zulässige Reihenfolgen und eine reale Zielfunktion festzulegen. 5.040 Möglichkeiten können für eine begrenzte Aufgabe als vollständige Referenz dienen. Direkten TRITON-Kern erst nach Randfallkorrekturen bei gleichem Auswertungsbudget gegen einfache Suche vergleichen. Das ist ein Forschungsentwurf, kein bereits integrierter Planer.')
h('Fundstellen')
p('Q = mitgeliefertes <i>qso-main</i>; G = Gabriel-Quellstand des aktuellen Arbeitsprojekts. Ausführliche Einzelbefunde und präzise Zeilenangaben stehen zusätzlich in den drei technischen Reviews im Prüfarchiv.','small')
refs=[
 ('Q1','metatron-qso-rs/src/graph/metatron.rs, insbesondere 204-357 und 376-522; src/hamiltonian.rs:31-74,161-175; src/qso.rs:25-101.'),
 ('Q2','metatron-qso-rs/src/quantum_walk_toolkit.rs:72-145 (Zentralität und Anomalie).'),
 ('Q3','metatron-qso-rs/src/quantum_walk/continuous.rs:29-110 (Zustandsaktion, Zeitmittel, Dephasierung).'),
 ('Q4','metatron-qso-rs/src/quantum_walk/krylov.rs:71-142; analysis.rs:169-172,218-248; docs/quantum_walk_mixing.md:175-187.'),
 ('Q5','external/dioniceos/infinity-ledger/: mef-core/src/symmetries.rs und geometry.rs; mef-topology/src/metatron_router.rs; mef-router/src/{s7,s7_space,route_selection}.rs.'),
 ('Q6','metatron_triton/src/{search,strategy,spiral}.rs; metatron_backend/src/backends/{local,ibm}.rs; scs/calibrator.py; metatron_telemetry/src/api/handlers.rs; metatron_dionice_bridge/src/lib.rs.'),
 ('G1','native_pse/crates/pse-metatron/src/{group,embed,scan,small_signature,indexed_signature,bitgraph}.rs; generate_d6 insbesondere group.rs:127-133.'),
 ('G2','native_pse/crates/pse-topology/src/lib.rs:486-579 (spektrale Paarabfragen und Phasenwiederverwendung).'),
 ('G3','gabriel_runtime/CONTRACT.md:7-23 und REPLAY.md:8-25 (Zustandsbesitz, Commit und Wiederholung).'),
]
for key, value in refs: p('<b>'+key+'</b> '+escape(value),'small')
p('Quellidentität SHA256 (qso-main.zip):<br/>'+integrity['sha256'],'small')

def pageframe(c,doc):
    w,hh=A4;c.setStrokeColor(accent);c.setLineWidth(1.2);c.line(48,hh-34,w-48,hh-34)
    c.setFont('Review',8);c.setFillColor(muted);c.drawString(48,25,'GABRIEL / QSO · Technischer Prüfbericht · 26.09.2026');c.drawRightString(w-48,25,str(doc.page))

SimpleDocTemplate(str(OUT),pagesize=A4,rightMargin=48,leftMargin=48,topMargin=49,bottomMargin=45,title='QSO für Gabriel: Substanz, Grenzen und übertragbare Kerne',author='',pageCompression=1).build(story,onFirstPage=pageframe,onLaterPages=pageframe)
(HERE/'Gabriel_QSO_Pruefbericht.md').write_text('\n'.join(md),encoding='utf-8')
print(OUT)
