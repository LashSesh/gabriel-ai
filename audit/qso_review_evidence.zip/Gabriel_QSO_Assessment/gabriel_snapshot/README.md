# Gabriel source excerpt

This read-only excerpt preserves the actual native Metatron files inspected in
this QSO comparison, including the auxiliary group API and signature call paths.
It is not a complete buildable project. `source_manifest.json` records SHA256
hashes and sizes. Production sources were not modified.

To reproduce the finite source-model checks from any extraction directory:

```sh
python3 checks/reproduce_s7_contracts.py --qso-root /path/to/qso-main --gabriel-root /path/to/gabriel_snapshot --output /path/to/new-results.json
```

The QSO root must be an extracted original repository containing `external/`.
The Gabriel root may also be a complete Gabriel project containing `native_pse/`.
The default paths assume `checks/`, `source/qso-main/` and `gabriel_snapshot/`
are siblings within the review bundle. The script executes mathematical source
models, not Rust functions; the recorded hashes identify the reviewed sources.
