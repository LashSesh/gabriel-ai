"""Independent algebraic/numerical checks of QSO source formulas; not Rust execution.
Python 3, numpy/scipy; deterministic seed 20260926. Run from any directory.
"""
from pathlib import Path
import json, re, math, hashlib
import numpy as np
from scipy.linalg import expm
ROOT = Path(__file__).resolve().parents[1]
SRC=ROOT/'source/qso-main/metatron-qso-rs/src'
s=(SRC/'graph/metatron.rs').read_text()
edges=set()
def add(a,b):
    if a!=b: edges.add(tuple(sorted((a,b))))
for i in range(1,13): add(0,i)
for i in range(1,7): add(i, i%6+1)
for name in ['cube_edges','hex_cube_connections','additional_edges']:
    body=re.search(r'let '+name+r' = \[(.*?)\];',s,re.S).group(1)
    for a,b in re.findall(r'\((\d+),\s*(\d+)\)',body): add(int(a),int(b))
for a,b in [(1,4),(2,5),(3,6)]:add(a,b)
n=13; A=np.zeros((n,n))
for a,b in edges:A[a,b]=A[b,a]=1
L=np.diag(A.sum(axis=1))-A
assert len(edges)==78 and np.array_equal(A,np.ones((n,n))-np.eye(n))
# Mirror the permutation generators, including exact reflection indexing.
h=list(range(1,7)); c=list(range(7,13))
hp=[h[:]]+[[h[(i+k)%6] for i in range(6)] for k in range(1,6)]
hp += [[h[(axis+((axis-i)%6))%6] for i in range(6)] for axis in range(6)]
cp=[c[:],[c[1],c[0],c[3],c[2],c[4],c[5]],
[c[2],c[3],c[0],c[1],c[5],c[4]],[c[5],c[4],c[3],c[2],c[1],c[0]]]
perms=[tuple([0]+p+q) for p in hp for q in cp]; unique=set(perms)
missing=None
for p in unique:
 for q in unique:
  r=tuple(p[q[i]] for i in range(n))
  if r not in unique: missing={'p':p,'q':q,'composition':r};break
 if missing:break
assert len(perms)==48 and len(unique)==36 and missing
# Analytic complete-graph propagator, all random initial states checked against expm.
rng=np.random.default_rng(20260926)
errors=[]
P=np.ones((n,n))/n; I=np.eye(n)
for j in [.25,1.,1.7]:
 for t in [0.,.1,.25,1.,10.]:
  exact=P+np.exp(1j*j*n*t)*(I-P)
  errors.append(float(np.max(np.abs(expm(1j*j*L*t)-exact))))
# The toolkit's normalized aggregate is constant for EVERY unitary, even nonregular graphs.
centrality={}
for name,Adj in [('K13',A),('P13',np.eye(n,k=1)+np.eye(n,k=-1)),('empty',np.zeros((n,n)))]:
 Lap=np.diag(Adj.sum(axis=1))-Adj
 values=np.zeros(n)
 for t in np.arange(1,11)*.5:
  U=expm(1j*Lap*t)
  values+=(np.abs(U)**2).sum(axis=1)
 values/=(n*10);values/=max(values)
 centrality[name]=values.tolist()
# Degenerate Cesaro formula must use spectral projectors, not individual eigenvectors.
# Construct valid real orthonormal bases with same uniform eigenvector and rotate complement.
v=np.eye(n);v[:,0]=1
Q,_=np.linalg.qr(v)
R,_=np.linalg.qr(rng.normal(size=(n-1,n-1)))
Q2=Q.copy();Q2[:,1:]=Q[:,1:]@R
initial=I[:,0]
true_average=np.abs(P@initial)**2+np.abs((I-P)@initial)**2
old_avgs=[]
for V in [Q,Q2]:
 weights=np.abs(V.T@initial)**2
 old=(np.abs(V)**2)@weights
 old/=sum(old)
 old_avgs.append(old)
assert np.max(np.abs(old_avgs[0]-old_avgs[1]))>1e-3
# m=1 Lanczos reports beta.last().unwrap_or(0) = 0 even though defect nonzero.
t=.1;H=-L;alpha=H[0,0]
approx=np.exp(-1j*alpha*t)*initial;exact=expm(-1j*H*t)@initial
residual_m1={'dimension':1,'time':t,'reported_residual':0.0,
 'actual_schrodinger_defect_norm':float(np.linalg.norm(H@initial-alpha*initial)),
 'state_error_norm':float(np.linalg.norm(approx-exact))}
# Mirror the claimed hitting statistic for uniform K13, no dephasing.
hit={}
for steps in [1,12,24,48]:
 survival=1.;partial=0.;dt=.25
 for k in range(1,steps+1):
  p=4*math.sin(n*k*dt/2)**2/(n*n)
  f=survival*p;partial+=f*k;survival*=1-p
 hit[str(steps)]={'finite_horizon_first_moment':partial,'success_probability':1-survival,
 'claimed_speedup_12_over_partial':12/partial,
 'conditional_first_moment':partial/(1-survival),
 'censored_mean_min_T_N':partial+steps*survival,
 'lower_bound_on_unconditional_mean':partial+(steps+1)*survival}
result={
 'status':'Independent Python reproduction of source formulas; no Rust build or runtime invocation.',
 'source_sha256':{str(p.relative_to(SRC)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [SRC/'graph/metatron.rs',SRC/'quantum_walk/continuous.rs',SRC/'quantum_walk_toolkit.rs',SRC/'quantum_walk/krylov.rs',SRC/'quantum_walk/analysis.rs']},
 'graph':{'nodes':13,'edges':len(edges),'is_K13':True,'L_equals_13I_minus_ones':bool(np.array_equal(L,13*np.eye(n)-np.ones((n,n)))),'uncolored_automorphism_order':math.factorial(13),'color_preserving_automorphism_order':math.factorial(6)**2},
 'enumeration':{'entries':len(perms),'unique':len(unique),'closed_under_composition':False,'missing_composition':missing},
 'complete_graph_exact_propagator_max_abs_error_against_scipy':max(errors),
 'centrality_implementation_mirror':centrality,
 'centrality_max_spread':{k:max(v)-min(v) for k,v in centrality.items()},
 'degenerate_cesaro':{'true_distribution':true_average.tolist(),'source_formula_basis1':old_avgs[0].tolist(),'source_formula_basis2':old_avgs[1].tolist(),'basis_dependence_max_abs':float(np.max(np.abs(old_avgs[0]-old_avgs[1]))),'formula_basis1_max_error':float(np.max(np.abs(old_avgs[0]-true_average)))},
 'krylov_dimension1':residual_m1,'hitting_statistic':hit}
out=Path(__file__).with_name('core_checks.json');out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['source_sha256','centrality_implementation_mirror','degenerate_cesaro']},indent=2))
