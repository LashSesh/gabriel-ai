#!/usr/bin/env python3
"""Finite source-model checks; no Rust execution and no performance claims.
Stdlib only. Exact integer/Fraction arithmetic except score formatting.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import permutations
from hashlib import sha256
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
Q = ROOT/'qso_review/source/qso-main/external/dioniceos/infinity-ledger'
G = ROOT/'recovered/project/Gabriel/native_pse/crates/pse-metatron/src'
FILES = [Q/'mef-core/src/symmetries.rs', Q/'mef-topology/src/metatron_router.rs',
         Q/'mef-router/src/s7.rs', Q/'mef-router/src/s7_space.rs',
         Q/'mef-router/src/route_selection.rs', Q/'mef-core/src/geometry.rs',
         G/'group.rs', G/'small_signature.rs', G/'indexed_signature.rs', G/'embed.rs']

def rotation(k):
    return (1,)+tuple(2+(i+k)%6 for i in range(6))

def reflection(axis):
    return (1,)+tuple(2+(2*(axis-2)-i)%6 for i in range(6))

def compose(a,b):
    return tuple(a[j-1] for j in b)

c6 = [rotation(i) for i in range(6)]
d6 = c6+[reflection(i) for i in range(2,8)]
closure_witness = next((a,b,compose(a,b)) for a in d6 for b in d6 if compose(a,b) not in d6)
proper_d6 = c6+[compose(rotation(k), reflection(2)) for k in range(6)]
assert len(set(d6)) == 9 and len(set(proper_d6)) == 12
assert all(compose(a,b) in proper_d6 for a in proper_d6 for b in proper_d6)

# Faithful small translations of the two source enumerators.
def recursive_perms():
    out=[]; arr=list(range(1,8))
    def rec(start):
        if start==len(arr):
            out.append(tuple(arr)); return
        for i in range(start,len(arr)):
            arr[start],arr[i]=arr[i],arr[start]; rec(start+1)
            arr[start],arr[i]=arr[i],arr[start]
    rec(0); return out

def heap_perms():
    out=[]; arr=list(range(1,8))
    def rec(k):
        if k==1: out.append(tuple(arr))
        else:
            for i in range(k):
                rec(k-1)
                j=i if k%2==0 else 0
                arr[j],arr[k-1]=arr[k-1],arr[j]
    rec(7); return out

recursive, heap = recursive_perms(),heap_perms()
expected=set(permutations(range(1,8)))
assert len(heap)==len(recursive)==len(set(heap))==len(set(recursive))==5040
assert set(heap)==set(recursive)==expected
first_different=next(i for i in range(5040) if heap[i]!=recursive[i])

extended = [p+tuple(range(8,14)) for p in recursive]
sequence_indices=sorted({sum(p)%4 for p in extended})
assert sequence_indices==[3]
first_candidates=[tuple(range(1,14))]+[p+tuple(range(8,14)) for p in c6[:3]+d6[:3]]
assert len(first_candidates)==7 and len(set(first_candidates))==3

# For finite nonnegative input, the router sorting/un-sorting is identity,
# so its claimed PI projection is exactly (2I+R+R^2)/4 on the hexagon.
def act(p,x): return tuple(x[i-1] for i in p)
def pi(x):
    ps=[x]+[act(p,x) for p in c6[:3]]
    return tuple(sum(q[i] for q in ps)/4 for i in range(7))
x=tuple(F(int(i==1)) for i in range(7))
px=pi(x); ppx=pi(px); prx=pi(act(c6[1],x))
assert px!=ppx and px!=prx

# An S7 relabeling exchanging centre and a hexagon node is not
# a geometric isometry, nor an automorphism of the centre+cycle wheel.
wheel={tuple(sorted(e)) for e in [(1,j) for j in range(2,8)]+[(2+i,2+(i+1)%6) for i in range(6)]}
swap=(2,1,3,4,5,6,7)
wheel_after={tuple(sorted((swap[a-1],swap[b-1]))) for a,b in wheel}
assert wheel_after!=wheel

score=0.10*2.0+0.70*0.5+0.20*0.3
seed='seed123'
hash_value=int.from_bytes(sha256((seed+format(score,'.6f')).encode()).digest()[:8],'little')
index64=hash_value%5040; index32=(hash_value&((1<<32)-1))%5040
assert index64!=index32

result={
 'status':'source-level mathematical models executed; Rust APIs not executed',
 'source_sha256':{str(p.relative_to(ROOT)):sha256(p.read_bytes()).hexdigest() for p in FILES},
 's7_enumerators':{'count_each':5040,'unique_each':5040,'same_set':True,'first_different_index':first_different,'recursive_at_index':recursive[first_different],'heap_at_index':heap[first_different]},
 'd6':{'entries':len(d6),'distinct':len(set(d6)),'reflection_axis_2':reflection(2),'reflection_axis_5':reflection(5),'closure_witness_a_b_product':closure_witness,'corrected_construction_distinct':len(set(proper_d6)),'corrected_construction_closed':True},
 'metatron_router':{'all_5040_sequence_indices':sequence_indices,'sequence':['WT','PI','SW','DK'],'initial_candidate_entries':7,'initial_candidate_distinct':3,'maximum_distinct_of_default_10_candidates':6},
 'pi_counterexample':{k:list(map(str,v)) for k,v in {'x':x,'P_x':px,'P_P_x':ppx,'P_R_x':prx}.items()},
 's7_not_wheel_automorphisms':{'permutation':swap,'lost_edges':sorted(wheel-wheel_after),'added_edges':sorted(wheel_after-wheel)},
 'word_size_route_counterexample':{'seed':seed,'metrics':{'betti':2,'lambda_gap':.5,'persistence':.3},'formatted_score':format(score,'.6f'),'hash_u64':hash_value,'index64':index64,'index32':index32}
}
(HERE/'s7_contracts.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='source_sha256'},indent=2))
