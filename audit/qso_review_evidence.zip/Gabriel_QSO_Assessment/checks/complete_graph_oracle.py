"""Experimental reference formulas for uniformly weighted complete graphs.

Independent extraction for Gabriel review; not integrated into either Rust engine.
No hardware or performance claim. Floating-point residual checks are numerical
validation, not certified rounding bounds or automatic proofs of degeneracy.

H = sign * coupling * weight * (n I - 11^T) + onsite I.
QSO uses sign=-1; Gabriel's Laplacian CTQW uses sign=+1.
"""
from __future__ import annotations
import numpy as np


def _state(state):
    state = np.asarray(state, dtype=np.complex128)
    if state.ndim != 1 or state.size == 0 or not np.all(np.isfinite(state)):
        raise ValueError('state must be a nonempty finite complex vector')
    return state


def _parameters(coupling, weight, onsite, sign):
    vals = np.asarray([coupling, weight, onsite, sign], dtype=float)
    if not np.all(np.isfinite(vals)) or sign not in (-1, 1) or weight < 0:
        raise ValueError('parameters must be finite; weight >= 0 and sign in {-1,+1}')
    return tuple(float(x) for x in vals)


def complete_graph_state_action(state, time, *, coupling=1., weight=1., onsite=0., sign=-1):
    """O(n) action exp(-itH) state, preserving arbitrary input norm mathematically.

    No normalization or fallback state is introduced. The only graph accepted by
    this parameter-only interface is a uniformly weighted complete graph. Caller
    must not infer this condition from an unweighted presence signature.
    """
    state = _state(state)
    coupling, weight, onsite, sign = _parameters(coupling, weight, onsite, sign)
    time = float(time)
    with np.errstate(over='ignore', invalid='ignore'):
        phase = float(sign * coupling * weight * len(state) * time)
        common_phase = float(onsite * time)
        mean = state.mean()
    if not np.isfinite(time) or not np.isfinite(phase) or not np.isfinite(common_phase) or not np.isfinite(mean):
        raise ValueError('finite representable time, phases and state mean required')
    result = np.exp(-1j * common_phase) * (mean + np.exp(-1j * phase) * (state - mean))
    if not np.all(np.isfinite(result)):
        raise ValueError('state action overflowed')
    return result


def complete_graph_cesaro(state, *, coupling=1., weight=1., onsite=0., sign=-1):
    """True infinite-time average of component intensities for the given model.

    Zero coupling/weight collapses both eigenspaces to one energy; then the full
    state is stationary up to a common phase. Do not split that degeneracy.
    For nonzero coupling and weight, tiny represented numbers are treated as
    mathematically nonzero; the infinite-time limit can be discontinuous at zero.
    """
    state = _state(state)
    coupling, weight, onsite, sign = _parameters(coupling, weight, onsite, sign)
    if coupling == 0 or weight == 0 or len(state) == 1:
        result = np.abs(state)**2
    else:
        mean = state.mean()
        result = np.abs(mean)**2 + np.abs(state - mean)**2
    if not np.all(np.isfinite(result)):
        raise ValueError('intensity calculation overflowed')
    return result


def projector_cesaro(hamiltonian, state, energies, projectors, *, atol=1e-10):
    """Compute sum_E |P_E state|^2 for explicitly supplied whole eigenspaces.

    The caller provides the mathematical degeneracy grouping. This function
    DOES NOT automatically merge close numerical eigenvalues. It checks finite
    Hermitian H and numerically validates the proposed orthogonal spectral
    resolution: Hermitian/idempotent/nonzero projectors, orthogonality, identity
    sum, distinct stated energies, and H P_E = E P_E. at this tolerance, these
    checks can accept a slightly perturbed model; they are not a proof of exact
    energy equality and do not certify the infinite-time limit of an arbitrary
    near-degenerate H.
    """
    state = _state(state)
    n = len(state)
    H = np.asarray(hamiltonian, dtype=np.complex128)
    if H.shape != (n, n) or not np.all(np.isfinite(H)):
        raise ValueError('Hamiltonian must have matching finite square shape')
    if not np.isfinite(atol) or not 0 < atol < 1:
        raise ValueError('validation tolerance must lie strictly between zero and one')
    # Exact Hermitian input contract; approximate diagonalization residuals below
    # are independently permitted within atol for the explicit proposed model.
    if not np.array_equal(H, H.conj().T):
        raise ValueError('Hamiltonian must be Hermitian')
    energies = np.asarray(energies, dtype=float)
    projectors = [np.asarray(p, dtype=np.complex128) for p in projectors]
    if energies.ndim != 1 or len(energies) != len(projectors) or len(energies) == 0 or not np.all(np.isfinite(energies)):
        raise ValueError('one finite real energy is required for each projector')
    if len(np.unique(energies)) != len(energies):
        raise ValueError('merge all projectors with equal energy before evaluation')
    norm_H = float(np.linalg.norm(H))
    if not np.isfinite(norm_H):
        raise ValueError('Hamiltonian norm must be representable')
    for E, P in zip(energies, projectors):
        if P.shape != H.shape or not np.all(np.isfinite(P)):
            raise ValueError('projectors require matching finite square shape')
        norm_P = float(np.linalg.norm(P))
        if not np.isfinite(norm_P) or norm_P < 1 - atol:
            raise ValueError('zero-rank, oversized or nonprojector block')
        for residual in [P-P.conj().T, P@P-P]:
            residual_norm = float(np.linalg.norm(residual))
            if not np.isfinite(residual_norm) or residual_norm > atol * max(1., norm_P):
                raise ValueError('block is not a Hermitian orthogonal projector')
        defect = float(np.linalg.norm(H@P - E*P))
        if not np.isfinite(defect) or defect > atol * max(1., norm_H, abs(E)):
            raise ValueError('block is not an eigenspace of the supplied Hamiltonian')
    for i, P in enumerate(projectors):
        for Q in projectors[:i]:
            overlap = float(np.linalg.norm(P@Q))
            if not np.isfinite(overlap) or overlap > atol:
                raise ValueError('spectral blocks are not mutually orthogonal')
    resolution_defect = float(np.linalg.norm(sum(projectors) - np.eye(n)))
    if not np.isfinite(resolution_defect) or resolution_defect > atol * max(1., np.sqrt(n)):
        raise ValueError('projectors do not resolve the identity')
    result = sum(np.abs(P @ state)**2 for P in projectors)
    if not np.all(np.isfinite(result)):
        raise ValueError('intensity calculation overflowed')
    return result
