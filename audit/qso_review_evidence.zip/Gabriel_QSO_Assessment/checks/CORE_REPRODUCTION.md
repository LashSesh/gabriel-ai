# Core formula reproduction and experimental extraction

These Python programs inspect/reproduce mathematical formulas from the uploaded QSO source. They neither compile nor execute Rust. They do not modify QSO or Gabriel. The original `core_checks.py` and `core_checks.json` are retained unchanged.

Requirements used in the executed checks: Python 3, NumPy 2.3.5, SciPy 1.17.0. Install them into a suitable Python environment if absent. No network access is required once dependencies and the uploaded repository are present.

Reproduce the source-formula findings from anywhere:

```bash
python reproduce_core_checks.py --qso-root /path/to/qso-main --output reproduced_core_checks.json
```

`--qso-root` may also point directly to `/path/to/qso-main/metatron-qso-rs`. The script requires the source files listed by its SHA-256 manifest; it mirrors the current reviewed edge arrays and formulas, rather than interpreting arbitrary future Rust programs. The executed portable reproduction was byte-identical to the retained original JSON.

The independent experimental extraction needs no QSO source:

```bash
python test_complete_graph_oracle.py --output complete_graph_oracle_validation.json
```

`complete_graph_oracle.py` exposes:

* `complete_graph_state_action`: O(n) vector action for a known uniformly weighted complete graph with a common onsite potential. It uses one vector mean and two phases. It supports either the QSO or Gabriel Laplacian sign convention; it does not normalize or replace input states.
* `complete_graph_cesaro`: the true infinite-time component-intensity average for that same model, treating zero coupling/weight as a single fully degenerate eigenspace.
* `projector_cesaro`: a general reference for the sum over **whole distinct-energy eigenspaces**. The caller supplies the grouping and projectors. Finite Hermitian input, dimensions, projector properties, completeness, and spectral residuals are checked. Near-equal floating-point eigenvalues are not automatically declared equal. These numerical checks are not formal degeneracy or rounding certificates.

The recorded run covers 360 normalized complex state-action cases with n = 1, 2, 3, 7, 13, 31, both Laplacian signs, coupling −0.5/1, weight 0/0.25/1.7, onsite 0.37, and time −2/0/0.1/0.25/3. The maximum L2 discrepancy against SciPy matrix exponentiation is 8.81e−14; maximum norm error is 3.34e−16. Degenerate-basis rotation, zero coupling, zero input, the analytic K13 Cesàro distribution and 12 malformed-input cases are checked separately. The output records all parameters, tolerances, dependency versions and implementation hash.

The operation count of the specialized state action follows from its code. **No speed benchmark was run, and no production-engine integration is included.** Uniform weighting must be established from actual edge weights; Gabriel's unweighted graph-presence signature cannot establish it. Algebraic equivalence does not promise bitwise equality with the existing eigensolver or identical threshold decisions arbitrarily close to a threshold.
