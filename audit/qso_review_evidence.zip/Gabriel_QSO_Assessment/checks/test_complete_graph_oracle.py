"""Execute deterministic scientific reference checks; write JSON using --output.

Usage: python test_complete_graph_oracle.py --output oracle_validation.json
Requirements: Python 3, NumPy, SciPy. No Rust source or binary is required.
"""
from pathlib import Path
import argparse, json, hashlib
import numpy as np
import scipy
from scipy.linalg import expm
from complete_graph_oracle import complete_graph_state_action, complete_graph_cesaro, projector_cesaro


def run():
    rng = np.random.default_rng(20260926)
    norm_errors=[]; state_errors=[]; cesaro_errors=[]; cases=0
    dimensions=[1,2,3,7,13,31]
    for n in dimensions:
        initial=rng.normal(size=n)+1j*rng.normal(size=n)
        initial/=np.linalg.norm(initial)
        P=np.ones((n,n))/n; Q=np.eye(n)-P
        L=n*np.eye(n)-np.ones((n,n))
        for sign in [-1,1]:
            for coupling in [-.5,1.]:
                for weight in [0.,.25,1.7]:
                    onsite=.37
                    H=sign*coupling*weight*L+onsite*np.eye(n)
                    if weight == 0 or n == 1:
                        energies=[onsite]; blocks=[np.eye(n)]
                    else:
                        energies=[onsite, onsite+sign*coupling*weight*n]; blocks=[P,Q]
                    grouped=projector_cesaro(H,initial,energies,blocks)
                    formula=complete_graph_cesaro(initial,coupling=coupling,weight=weight,onsite=onsite,sign=sign)
                    cesaro_errors.append(float(np.max(np.abs(grouped-formula))))
                    assert abs(sum(formula)-np.linalg.norm(initial)**2)<2e-12
                    for time in [-2.,0.,.1,.25,3.]:
                        actual=complete_graph_state_action(initial,time,coupling=coupling,weight=weight,onsite=onsite,sign=sign)
                        reference=expm(-1j*H*time)@initial
                        state_errors.append(float(np.linalg.norm(actual-reference)))
                        norm_errors.append(float(abs(np.linalg.norm(actual)-1)))
                        cases+=1
    assert max(state_errors)<2e-11 and max(norm_errors)<2e-12 and max(cesaro_errors)<2e-12
    # Complete K13 basis initial state: exact rational long-time probabilities.
    initial=np.eye(13)[0]
    avg=complete_graph_cesaro(initial)
    assert abs(avg[0]-145/169)<2e-15
    assert np.max(abs(avg[1:]-2/169))<2e-15
    # Explicit degenerate group projectors do not change under a basis rotation.
    V=np.eye(13); V[:,0]=1; V,_=np.linalg.qr(V)
    R,_=np.linalg.qr(rng.normal(size=(12,12)))
    V2=V.copy(); V2[:,1:]=V[:,1:]@R
    H=-(13*np.eye(13)-np.ones((13,13)))
    averages=[]
    for U in [V,V2]:
        blocks=[U[:,:1]@U[:,:1].T,U[:,1:]@U[:,1:].T]
        averages.append(projector_cesaro(H,initial,[0.,-13.],blocks))
    rotation_error=float(np.max(abs(averages[0]-averages[1])))
    assert rotation_error<2e-12
    assert np.max(abs(averages[0]-avg))<2e-12
    # Degenerate collapse H=epsilon I must retain all coherences, not dephase.
    x=np.asarray([1,1j,-.3],complex); x/=np.linalg.norm(x)
    zero_coupling=complete_graph_cesaro(x,coupling=0)
    assert np.array_equal(zero_coupling,np.abs(x)**2)
    assert np.array_equal(complete_graph_state_action(np.zeros(3),1),np.zeros(3))
    # Reject common malformed-input cases. No silent state replacement.
    rejections={}
    probes={
      'empty_state':lambda:complete_graph_state_action([],1),
      'matrix_state':lambda:complete_graph_state_action(np.eye(2),1),
      'nonfinite_state':lambda:complete_graph_state_action([np.nan,0],1),
      'nonfinite_time':lambda:complete_graph_state_action([1,0],np.inf),
      'negative_weight':lambda:complete_graph_state_action([1,0],1,weight=-1),
      'invalid_sign':lambda:complete_graph_state_action([1,0],1,sign=0),
      'Hamiltonian_shape':lambda:projector_cesaro(np.eye(3),[1,0],[1],[np.eye(2)]),
      'Hamiltonian_nonfinite':lambda:projector_cesaro(np.array([[np.nan,0],[0,1]]),[1,0],[1],[np.eye(2)]),
      'Hamiltonian_nonsymmetric':lambda:projector_cesaro(np.array([[0,1],[0,0]]),[1,0],[0],[np.eye(2)]),
      'overlapping_projectors':lambda:projector_cesaro(np.eye(2),[1,0],[1,2],[np.eye(2),np.eye(2)]),
      'incomplete_resolution':lambda:projector_cesaro(np.diag([1.,2.]),[1,0],[1],[np.diag([1.,0.])]),
      'duplicate_energies':lambda:projector_cesaro(np.eye(2),[1,0],[1,1],[np.diag([1,0]),np.diag([0,1])]),
    }
    for name,fn in probes.items():
        try: fn()
        except ValueError: rejections[name]=True
        else: raise AssertionError('failed to reject '+name)
    return {'status':'Experimental analytic reference, independent Python execution; no Rust integration or performance measurement.',
      'seed':20260926,'numpy':np.__version__,'scipy':scipy.__version__,
      'source_sha256':hashlib.sha256(Path(__file__).with_name('complete_graph_oracle.py').read_bytes()).hexdigest(),
      'state_action_cases':cases,'dimensions':dimensions,'signs':[-1,1],'couplings':[-.5,1.],
      'weights':[0.,.25,1.7],'onsite':.37,'times':[-2.,0.,.1,.25,3.],
      'max_state_l2_error_against_scipy_expm':max(state_errors),'max_norm_error':max(norm_errors),
      'max_cesaro_error_against_explicit_projector_sum':max(cesaro_errors),
      'degenerate_basis_rotation_max_error':rotation_error,'K13_basis_return_average':float(avg[0]),
      'K13_other_average':float(avg[1]),'malformed_input_rejections':rejections,
      'tolerances':{'state_l2':2e-11,'norm':2e-12,'cesaro':2e-12,'projector_validation':1e-10},
      'limits':['Known uniformly weighted clique and uniform onsite potential required.',
       'Grouping into whole equal-energy eigenspaces is an explicit input; close numeric eigenvalues are not automatically merged.',
       'Numerical residual checks are not certified floating-point or exact degeneracy proofs.',
       'No wall-clock performance benchmark and no production-engine changes.']}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    result=run()
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
