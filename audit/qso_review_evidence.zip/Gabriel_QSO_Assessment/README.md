# QSO for Gabriel: technical assessment and reproducible evidence

This is a **review and experimental reference package**, not a replacement Gabriel release. Start with `Gabriel_QSO_Pruefbericht.pdf` (German, six pages). Its source is `build_report.py` and the generated text is `Gabriel_QSO_Pruefbericht.md`. Three detailed English source reviews are included for traceability.

The supplied QSO source and current Gabriel production sources were not modified. The original upload is preserved as `input/qso-main.zip`; its SHA256 is `0c20d1f9f936471a13eaa8aad52c8fd8295c7ecc9d959191ca7e97e9c74ce216`. It contains 600 ZIP entries, 467 regular files. The original extracted files were compared against the archive byte-for-byte. The two Gabriel snapshots are **read-only source excerpts**, not independently buildable Gabriel distributions.

## Contents and evidentiary status

- `checks/reproduce_s7_contracts.py`: portable finite mathematical mirrors of source algorithms; standard Python library only.
- `checks/reproduce_core_checks.py`: portable numerical mirrors of source formulas; NumPy and SciPy.
- `checks/complete_graph_oracle.py`: newly implemented independent reference formulas for uniformly weighted complete graphs, plus a whole-eigenspace Cesaro reference. Experimental, no production integration.
- `checks/test_complete_graph_oracle.py`: actually executed reference checks: 360 state-action cases, zero coupling, degenerate eigenspaces, zero state and 12 malformed-input cases.
- Original source-model scripts and JSON records retained unchanged. The portable reproductions produced byte-identical JSON outputs. Those Python scripts did not execute Rust APIs.
- `checks/workspace_core_*`: actual Rust command records, stdout and stderr, including failed attempts. Final adjusted original-core suite: **31 passed**, no failed or ignored tests. `cargo check` also passed. These results concern `metatron-qso-rs --lib`, not all workspace crates, examples, doctests or integration tests.
- `gabriel_snapshot`: eleven unchanged native signature source files and a manifest; `gabriel_context_snapshot`: topology implementation and runtime contract/replay documentation, separately hashed.
- `manifest_sha256.json`: all packaged files except the manifest itself. It detects byte changes; it is not a signature or endorsement of scientific claims.

## Reproduce the mathematical checks

Use Python 3.12. Recorded numerical versions: NumPy 2.3.5 and SciPy 1.17.0. Dependencies are **not vendored**; install `requirements-checks.txt` into a suitable environment if needed. The scripts require no network once dependencies and source files are available. From this directory:

```bash
python -m zipfile -e input/qso-main.zip source
mkdir -p rerun
python checks/reproduce_s7_contracts.py --qso-root source/qso-main --gabriel-root gabriel_snapshot --output rerun/s7.json
python checks/reproduce_core_checks.py --qso-root source/qso-main --output rerun/core.json
python checks/test_complete_graph_oracle.py --output rerun/clique.json
```

The finite source-model checks mirror the reviewed source version; they do not parse arbitrary future implementations. Source hashes bind the present evidence. See `checks/CORE_REPRODUCTION.md` and `gabriel_snapshot/README.md` for detailed contracts. The original `core_checks.py` / `s7_contracts.py` retain their historical workspace assumptions; use the `reproduce_*` scripts for portable runs.

## Reproduce the original Rust core tests

The executed environment used Rust 1.95.0. Cargo dependencies and the toolchain are **not vendored**. The input archive contains its original Cargo.lock. A first offline attempt lacked dependencies; an online attempt downloaded them but failed when creating a Criterion archive. The final successful attempt changed build settings, not source:

```bash
cd source/qso-main
CARGO_PROFILE_DEV_LTO=false CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_DEV_CODEGEN_UNITS=1 CARGO_INCREMENTAL=0 cargo test --locked --offline --jobs 1 -p metatron-qso-rs --lib
```

Omit `--offline` only when intentionally allowing Cargo to acquire missing dependencies. All original command results are retained separately rather than replacing the failures with the eventual success. The successful type check used the same no-LTO/debug/incremental settings without the codegen-units override. No timing in those command logs is a QSO-versus-Gabriel performance result.

## Rebuild the report

Install ReportLab in the Python environment, then `python build_report.py`. The supplied DejaVu fonts and their license are in `report_assets`. The report reads saved evidence; it does not rerun the experiments. The generated PDF was rendered and visually checked before delivery. No original publications or Gabriel release artifacts are replaced by this report.

## Interpretation

The main result is selective reusability: exact clique reference, conditioned state-action interface, and a possible bounded operator planner. The group-action mismatch, constant centrality, faulty diagnostics, incomplete calibration/backends and adapter boundaries are explicitly documented. No new performance factor, quantum computational advantage, general learning advantage, or novelty priority is claimed. An inherited auxiliary D6 defect is identified; the currently used Gabriel S7 signature paths do not call that API. Its corrected finite group construction appears only in the independent checks and has not been patched into production.
