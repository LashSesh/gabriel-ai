# Exhaustively verified finite orbit index

The tables encode the existing zero-padded seven-slot S7 graph action. Every
binary undirected graph is a 21-bit word, with edge (i,j), i<j, at bit
`j*(j-1)/2+i`. Minimum selection uses the upper triangle in row-major order,
with the first entry most significant, preserving the legacy matrix convention.

All files use little-endian integers:

| File | Meaning | Bytes |
|---|---|---:|
| s7_classes.bin | One u16 class ID for each of 2^21 words | 4,194,304 |
| s7_metadata.bin | 1,044 rows of four u32: representative, canonical edge word, orbit cardinality, stabilizer order | 16,704 |
| s7_witnesses.bin | One packed forward vertex permutation for each graph, three bits per image coordinate | 8,388,608 |

The first two files supply runtime lookup. The third supplies offline witnesses.
Witnesses prohibit merging distinct orbits. Closure under the six adjacent
transpositions prohibits splitting an orbit. Nonempty fibers are therefore
exactly orbits. The matrix-action checker independently verifies every witness,
closure condition, class minimum and cardinality. It does not share the
generator's edge-action tables.

```bash
python native_pse/tools/reproduce_graph_index.py --output /path/to/new-directory
```

This command was actually executed with g++ and C++17. It compiles the two
standalone programs, regenerates the files twice, checks identical bytes against
the delivered data, rejects fourteen damaged certificates and accepts a different
valid witness for the empty graph. The execution record and hashes are in
`benchmark-results/indexed/results/verification_report.json`.

## Optional native consumer: explicit build gap

`pse-core/indexed-signature` changes the engine's bounded orbit call to table
lookup. Default builds keep the preceding packed implementation. Input checks
and original floating-point/subgraph routines are copied without changing their
order. This reconstructed Rust consumer has **not** been compiled or executed
in the recovered environment: rustc/cargo are unavailable, and the compiler
download was inaccessible. Consequently no new complete-signature equality or
end-to-end speed claim is attached to this source.

Before activation, run the included comparison tests on a supported Rust
toolchain and repeat the focused engine comparison. The supplied unfiltered
historical fixture failure from the preceding phase remains unresolved.

```bash
cargo test --manifest-path native_pse/Cargo.toml --locked --release \
  -p pse-metatron --features indexed-signature indexed_signature
cargo test --manifest-path native_pse/Cargo.toml --locked --release \
  --workspace --features pse-core/indexed-signature \
  -- --skip full_state_matches_original_golden_fixture
```

These two Rust commands are proposed verification steps, not executed results
for this reconstruction. The prior packed implementation's measured evidence
remains under `benchmark-results/gabriel/`. Its speed ratios must not be
multiplied by any unretained or unexecuted index measurement. The table does not
repair the inherited variable-size hash ambiguity or other PSE model limits.
